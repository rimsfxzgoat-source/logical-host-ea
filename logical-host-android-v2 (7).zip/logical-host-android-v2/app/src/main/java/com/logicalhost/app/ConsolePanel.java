package com.logicalhost.app;

import android.content.Context;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * The Bot Console as a small floating card over other apps.
 * Same layout as the new web console (lh-console-mini.css): header with the bot,
 * self-host strip, LIVE ACTIVITY folded behind MORE, CLEAR and ALL LOGS.
 */
public class ConsolePanel {

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    // colours from lh-console-mini.css
    private static final int BLUE_BRIGHT = 0xFF6F8BFF;
    private static final int GREEN = 0xFF33D17A;
    private static final int ORANGE = 0xFFFF8A3D;
    private static final int PILL_GREEN = 0xFF34D399;
    private static final int PILL_RED = 0xFFF87171;
    private static final int INK = 0xFFF3F5FB;
    private static final int INK_DIM = 0xFF8891A7;
    private static final int INK_FAINT = 0xFF5A6178;
    private static final int BAR = 0xFF6B7DA3;

    private final Context ctx;
    private final WindowManager wm;
    private final float d;

    private LinearLayout root;
    private WindowManager.LayoutParams wlp;
    private View accentLine;
    private ImageView avatar;
    private TextView nameTv, stateTv, hostSubTv, hostPill, moreCount, moreLabel;
    private View moreDot;
    private LinearLayout moreBtn, footer, list;
    private ScrollView feedScroll;
    private boolean feedOpen = false;
    private int accent = BLUE_BRIGHT;
    private boolean shown = false;
    private String lastJson = "";
    private int posX = Integer.MIN_VALUE;
    private int posY = Integer.MIN_VALUE;

    ConsolePanel(Context c) {
        ctx = c;
        wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
        d = c.getResources().getDisplayMetrics().density;
    }

    boolean isShown() {
        return shown;
    }

    void show() {
        if (shown || !Settings.canDrawOverlays(ctx)) return;
        build();
        try {
            wm.addView(root, wlp);
            shown = true;
        } catch (Exception e) {
            shown = false;
            root = null;
            return;
        }
        if (!lastJson.isEmpty()) render(lastJson);
        WebHost.requestSnapshot();
    }

    void hide() {
        if (!shown) return;
        try {
            wm.removeView(root);
        } catch (Exception ignored) {
        }
        shown = false;
        root = null;
    }

    void update(String json) {
        lastJson = json;
        if (shown) render(json);
    }

    void refreshPicture() {
        if (shown) paintPicture();
    }

    // ------------------------------------------------------------ helpers

    private int dp(float v) {
        return (int) (v * d + 0.5f);
    }

    private int alpha(int color, float a) {
        return (color & 0x00FFFFFF) | (((int) (a * 255f)) << 24);
    }

    private GradientDrawable box(int fill, float radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private TextView tv(String text, float sp, int color, boolean bold) {
        TextView t = new TextView(ctx);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private LinearLayout.LayoutParams lp(int w, int h, float weight, int top, int left, int right) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h, weight);
        p.topMargin = dp(top);
        p.leftMargin = dp(left);
        p.rightMargin = dp(right);
        return p;
    }

    private View dot(int color, int sizeDp) {
        View v = new View(ctx);
        v.setBackground(box(color, sizeDp, 0));
        return v;
    }

    // -------------------------------------------------------------- build

    private void build() {
        int sw = ctx.getResources().getDisplayMetrics().widthPixels;
        int sh = ctx.getResources().getDisplayMetrics().heightPixels;
        int w = Math.min(dp(264), (int) (sw * 0.92f));

        root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(box(0xF2101626, 16, 0x14FFFFFF));
        root.setClipToOutline(true);
        root.setOutlineProvider(ViewOutlineProvider.BACKGROUND);

        accentLine = new View(ctx);
        root.addView(accentLine, lp(MATCH, dp(1), 0, 0, 16, 16));

        // header: avatar, name and state, close (drag by this row)
        LinearLayout head = new LinearLayout(ctx);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(dp(11), dp(10), dp(9), dp(9));
        avatar = new ImageView(ctx);
        avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
        avatar.setClipToOutline(true);
        avatar.setOutlineProvider(ViewOutlineProvider.BACKGROUND);
        paintPicture();
        head.addView(avatar, new LinearLayout.LayoutParams(dp(30), dp(30)));

        LinearLayout idCol = new LinearLayout(ctx);
        idCol.setOrientation(LinearLayout.VERTICAL);
        nameTv = tv("BOT", 12.5f, INK, true);
        nameTv.setSingleLine(true);
        nameTv.setEllipsize(TextUtils.TruncateAt.END);
        stateTv = tv("", 9, accent, true);
        stateTv.setLetterSpacing(0.12f);
        stateTv.setSingleLine(true);
        idCol.addView(nameTv);
        idCol.addView(stateTv, lp(WRAP, WRAP, 0, 2, 0, 0));
        LinearLayout.LayoutParams idp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        idp.leftMargin = dp(9);
        head.addView(idCol, idp);

        TextView close = tv("\u2715", 11, INK_DIM, false);
        close.setGravity(Gravity.CENTER);
        close.setBackground(box(0x0DFFFFFF, 8, 0));
        close.setOnClickListener(v -> {
            KeepAliveService s = KeepAliveService.instance;
            if (s != null) s.hidePanel();
        });
        head.addView(close, new LinearLayout.LayoutParams(dp(24), dp(24)));
        root.addView(head, new LinearLayout.LayoutParams(MATCH, WRAP));
        drag(head);

        // self-host strip
        LinearLayout host = new LinearLayout(ctx);
        host.setOrientation(LinearLayout.HORIZONTAL);
        host.setGravity(Gravity.CENTER_VERTICAL);
        host.setPadding(dp(9), dp(6), dp(7), dp(6));
        host.setBackground(box(0x09FFFFFF, 9, 0));
        TextView hostTxt = tv("Self-host PC", 10.5f, INK_DIM, false);
        hostSubTv = tv("", 10.5f, INK_DIM, false);
        hostSubTv.setSingleLine(true);
        hostSubTv.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout hostText = new LinearLayout(ctx);
        hostText.setOrientation(LinearLayout.HORIZONTAL);
        hostText.addView(hostTxt);
        hostText.addView(tv(" \u00B7 ", 10.5f, INK_FAINT, false));
        hostText.addView(hostSubTv);
        host.addView(hostText, new LinearLayout.LayoutParams(0, WRAP, 1f));
        hostPill = tv("", 9.5f, PILL_GREEN, true);
        hostPill.setLetterSpacing(0.1f);
        hostPill.setPadding(dp(8), dp(2), dp(8), dp(2));
        host.addView(hostPill);
        root.addView(host, lp(MATCH, WRAP, 0, 0, 8, 8));

        // LIVE ACTIVITY (folded behind MORE)
        moreBtn = new LinearLayout(ctx);
        moreBtn.setOrientation(LinearLayout.HORIZONTAL);
        moreBtn.setGravity(Gravity.CENTER_VERTICAL);
        moreBtn.setPadding(dp(9), dp(7), dp(7), dp(7));
        moreBtn.setBackground(box(0x05FFFFFF, 9, 0x0FFFFFFF));
        moreDot = dot(PILL_GREEN, 5);
        moreBtn.addView(moreDot, new LinearLayout.LayoutParams(dp(5), dp(5)));
        TextView moreTitle = tv("LIVE ACTIVITY", 10, INK_DIM, true);
        moreTitle.setLetterSpacing(0.08f);
        LinearLayout.LayoutParams mt = new LinearLayout.LayoutParams(WRAP, WRAP);
        mt.leftMargin = dp(6);
        moreBtn.addView(moreTitle, mt);
        moreCount = tv("0", 8.5f, accent, true);
        moreCount.setPadding(dp(6), dp(1), dp(6), dp(1));
        moreCount.setBackground(box(alpha(accent, 0.15f), 999, 0));
        LinearLayout.LayoutParams mc = new LinearLayout.LayoutParams(WRAP, WRAP);
        mc.leftMargin = dp(6);
        moreBtn.addView(moreCount, mc);
        moreBtn.addView(new View(ctx), new LinearLayout.LayoutParams(0, 1, 1f));
        moreLabel = tv("MORE \u25BE", 9, accent, true);
        moreBtn.addView(moreLabel);
        moreBtn.setOnClickListener(v -> toggleFeed());
        root.addView(moreBtn, lp(MATCH, WRAP, 0, 6, 8, 8));

        // feed (hidden until MORE is tapped)
        list = new LinearLayout(ctx);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(6), 0, dp(6), dp(6));
        feedScroll = new ScrollView(ctx);
        feedScroll.addView(list, new ViewGroup.LayoutParams(MATCH, WRAP));
        feedScroll.setVisibility(feedOpen ? View.VISIBLE : View.GONE);
        root.addView(feedScroll, new LinearLayout.LayoutParams(MATCH, dp(150)));

        // footer: CLEAR and ALL LOGS
        footer = new LinearLayout(ctx);
        footer.setOrientation(LinearLayout.HORIZONTAL);
        footer.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        footer.setPadding(dp(8), dp(6), dp(8), dp(6));
        TextView clear = tv("CLEAR", 9.5f, INK_DIM, true);
        clear.setLetterSpacing(0.1f);
        clear.setPadding(dp(10), dp(4), dp(10), dp(4));
        clear.setBackground(box(0, 7, 0x14FFFFFF));
        clear.setOnClickListener(v -> WebHost.clickInPage(".lcm-foot .lcm-btn"));
        footer.addView(clear);
        TextView all = tv("ALL LOGS", 9.5f, INK_DIM, true);
        all.setLetterSpacing(0.1f);
        all.setPadding(dp(10), dp(4), dp(10), dp(4));
        all.setBackground(box(0, 7, 0x14FFFFFF));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(WRAP, WRAP);
        ap.leftMargin = dp(6);
        all.setOnClickListener(v -> {
            KeepAliveService s = KeepAliveService.instance;
            if (s != null) s.openApp();
        });
        footer.addView(all, ap);
        footer.setVisibility(feedOpen ? View.VISIBLE : View.GONE);
        root.addView(footer, new LinearLayout.LayoutParams(MATCH, WRAP));

        wlp = new WindowManager.LayoutParams(
                w, WRAP,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        wlp.gravity = Gravity.TOP | Gravity.START;
        wlp.x = posX == Integer.MIN_VALUE ? sw - w - dp(16) : posX;
        wlp.y = posY == Integer.MIN_VALUE ? (int) (sh * 0.45f) : posY;
    }

    private void toggleFeed() {
        feedOpen = !feedOpen;
        if (feedScroll != null) feedScroll.setVisibility(feedOpen ? View.VISIBLE : View.GONE);
        if (footer != null) footer.setVisibility(feedOpen ? View.VISIBLE : View.GONE);
        if (moreLabel != null) moreLabel.setText(feedOpen ? "LESS \u25B4" : "MORE \u25BE");
    }

    private void paintPicture() {
        if (avatar == null) return;
        if (BotPicture.bitmap != null) {
            avatar.setImageBitmap(BotPicture.bitmap);
        } else {
            avatar.setImageResource(R.drawable.bot_picture);
        }
    }

    private void drag(View handle) {
        handle.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy;
            float tx, ty;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = wlp.x;
                        sy = wlp.y;
                        tx = e.getRawX();
                        ty = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        wlp.x = sx + (int) (e.getRawX() - tx);
                        wlp.y = sy + (int) (e.getRawY() - ty);
                        posX = wlp.x;
                        posY = wlp.y;
                        try {
                            wm.updateViewLayout(root, wlp);
                        } catch (Exception ignored) {
                        }
                        return true;
                    default:
                        return true;
                }
            }
        });
    }

    // ------------------------------------------------------------- render

    private static int toneColor(String tone) {
        if ("ok".equals(tone)) return PILL_GREEN;
        if ("err".equals(tone)) return PILL_RED;
        if ("warn".equals(tone)) return ORANGE;
        if ("info".equals(tone)) return 0xFF7FA8FF;
        if ("idle".equals(tone)) return BAR;
        return BLUE_BRIGHT;
    }

    private void render(String json) {
        if (root == null) return;
        try {
            JSONObject o = new JSONObject(json);

            if (o.has("picture")) BotPicture.use(ctx, o.optString("picture", ""));

            String cls = o.optString("stateCls", "ana");
            accent = "exec".equals(cls) ? ORANGE : "mon".equals(cls) ? GREEN : BLUE_BRIGHT;
            nameTv.setText(o.optString("name", "BOT"));
            String st = o.optString("state", "");
            stateTv.setText("\u25CF " + (st.isEmpty() ? "Waiting for signal" : st).toUpperCase());
            stateTv.setTextColor(accent);
            accentLine.setBackground(new GradientDrawable(
                    GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{0x00000000, alpha(accent, 0.9f), 0x00000000}));
            moreDot.setBackground(box(accent, 5, 0));

            // self-host strip
            String lc = o.optString("linkCls", "off");
            boolean on = "on".equals(lc);
            boolean checking = "checking".equals(lc);
            int pc = on ? PILL_GREEN : checking ? INK_DIM : PILL_RED;
            hostSubTv.setText(on ? "EA running" : checking ? "Checking" : "EA not running");
            hostPill.setText(on ? "ON" : checking ? "\u2026" : "OFF");
            hostPill.setTextColor(pc);
            hostPill.setBackground(box(alpha(pc, 0.12f), 999, 0));

            // activity
            JSONArray items = o.optJSONArray("items");
            int n = items == null ? 0 : items.length();
            moreCount.setText(String.valueOf(n));
            moreCount.setTextColor(accent);
            moreCount.setBackground(box(alpha(accent, 0.15f), 999, 0));
            moreLabel.setTextColor(accent);
            list.removeAllViews();
            if (n == 0) {
                TextView empty = tv("Waiting for signal", 11, INK_FAINT, false);
                empty.setPadding(dp(6), dp(8), dp(6), dp(10));
                list.addView(empty);
            } else {
                for (int i = 0; i < n; i++) {
                    JSONObject it = items.getJSONObject(i);
                    list.addView(row(i == 0, it.optString("tone", "idle"), it.optString("title"),
                            it.optString("detail"), it.optString("ts"), it.optString("sym")),
                            lp(MATCH, WRAP, 0, i == 0 ? 0 : 2, 0, 0));
                }
            }
        } catch (Exception ignored) {
        }
    }

    private View row(boolean latest, String tone, String title, String detail, String ts, String sym) {
        int tc = toneColor(tone);
        LinearLayout r = new LinearLayout(ctx);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(6), dp(7), dp(6), dp(7));
        r.setBackground(latest ? box(alpha(tc, 0.08f), 9, 0) : box(0, 9, 0));

        View ico = dot(tc, 6);
        r.addView(ico, new LinearLayout.LayoutParams(dp(6), dp(6)));

        LinearLayout text = new LinearLayout(ctx);
        text.setOrientation(LinearLayout.VERTICAL);
        TextView t = tv(title, 11.5f, "err".equals(tone) ? 0xFFFCA5A5 : INK, true);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        text.addView(t);
        if (!detail.isEmpty()) {
            TextView s = tv(detail, 10, INK_FAINT, false);
            s.setSingleLine(true);
            s.setEllipsize(TextUtils.TruncateAt.END);
            text.addView(s);
        }
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        tp.leftMargin = dp(9);
        r.addView(text, tp);

        LinearLayout meta = new LinearLayout(ctx);
        meta.setOrientation(LinearLayout.VERTICAL);
        meta.setGravity(Gravity.END);
        if (!sym.isEmpty()) meta.addView(tv(sym, 9, tc, true));
        if (!ts.isEmpty()) {
            TextView m = tv(ts, 9, INK_FAINT, false);
            m.setTypeface(Typeface.MONOSPACE);
            meta.addView(m);
        }
        r.addView(meta, new LinearLayout.LayoutParams(WRAP, WRAP));
        return r;
    }
}
