(function () {
  if (window.__lhNative) return;
  window.__lhNative = true;

  function show(title, body) {
    try { window.AndroidNotify.show(String(title || ''), String(body || '')); } catch (e) {}
  }

  // 1) Notification polyfill. The chart scanner calls new Notification(...).
  function N(title, opts) {
    opts = opts || {};
    show(title, opts.body);
    this.close = function () {};
  }
  N.permission = 'granted';
  N.requestPermission = function (cb) {
    if (cb) cb('granted');
    return Promise.resolve('granted');
  };
  try {
    Object.defineProperty(window, 'Notification', { value: N, configurable: true, writable: true });
  } catch (e) {
    window.Notification = N;
  }

  // 2) Signal watcher. Reads the app's own EaSignal responses and notifies on NEW ones.
  var EV = { open: 1, close: 1, modify: 1, pending: 1 };
  var seen = {};
  var maxTs = 0;
  var ready = false;
  var bootAt = Date.now();   // only alerts created after the page started can notify

  function up(x) { return String(x == null ? '' : x).toUpperCase(); }
  function pos(x) { var n = Number(x); return isFinite(n) && n > 0 ? n : null; }

  function ts(e) {
    var s = e.created_date;
    if (!s) return 0;
    s = String(s);
    if (!/[zZ]$|[+-]\d\d:?\d\d$/.test(s)) s += 'Z';
    var t = Date.parse(s);
    return isNaN(t) ? 0 : t;
  }

  function build(e) {
    var sym = up(e.symbol);
    var dir = e.direction && e.direction !== 'none' ? up(e.direction) : '';
    var parts = [];
    if (pos(e.lot)) parts.push(pos(e.lot) + ' lot');
    if (pos(e.price)) parts.push('@ ' + e.price);
    if (pos(e.sl)) parts.push('SL ' + e.sl);
    if (pos(e.tp)) parts.push('TP ' + e.tp);
    var extra = parts.join(' \u00b7 ');
    var t, b;
    if (e.event === 'open') {
      t = (dir ? dir + ' ' : '') + sym;
      b = 'Trade opened' + (extra ? ' \u00b7 ' + extra : '');
    } else if (e.event === 'pending') {
      t = 'PENDING ' + (dir ? dir + ' ' : '') + sym;
      b = 'Entry order' + (extra ? ' \u00b7 ' + extra : '');
    } else if (e.event === 'modify') {
      t = sym + ' UPDATED';
      b = 'SL/TP changed' + (extra ? ' \u00b7 ' + extra : '');
    } else {
      t = sym + ' CLOSED';
      b = typeof e.profit === 'number' ? 'P/L ' + e.profit : 'Trade closed';
      if (extra) b += ' \u00b7 ' + extra;
    }
    if (e.message && e.account === 'manual') b = String(e.message);
    return [t, b];
  }

  function handle(list, isEventQuery) {
    var items = [], i, e;
    for (i = 0; i < list.length; i++) {
      e = list[i];
      if (e && e.id && EV[e.event]) items.push(e);
    }
    items.sort(function (a, b) { return ts(a) - ts(b); });
    var now = Date.now();
    for (i = 0; i < items.length; i++) {
      e = items[i];
      if (seen[e.id]) continue;
      seen[e.id] = 1;
      var t = ts(e);
      var fresh = t > 0 && t >= bootAt - 1000 && now - t < 300000;
      if (t > maxTs) maxTs = t;
      if (fresh) {
        var m = build(e);
        if (botOn) show(m[0], m[1]);
        else show('Signal received', m[0] + ' \u00b7 ' + m[1] + ' \u00b7 Turn the bot ON to trade');
      }
    }
    if (isEventQuery) ready = true;
  }

  function isEventUrl(url) {
    try { url = decodeURIComponent(url); } catch (e) {}
    return /open|close|modify|pending/.test(url) && !/heartbeat/.test(url);
  }

  function parse(data, url) {
    try {
      if (typeof data === 'string') data = JSON.parse(data);
      var list = Array.isArray(data) ? data :
        (data && (data.items || data.data || data.results || data.records || data.entities));
      handle(Array.isArray(list) ? list : [], isEventUrl(url));
    } catch (e) {}
  }


  // 3) Bot ON/OFF detection (drives the floating bubble).
  // While the bot is ON the app polls EaSignal events and updates StudentStatus.
  var botOn = false, lastSeen = 0;
  function reportBot() {
    try { window.AndroidNotify.botState(botOn); } catch (e) {}
  }
  function setBot(on) {
    if (on === botOn) return;
    botOn = on;
    reportBot();
  }
  setInterval(reportBot, 5000);
  reportBot();
  function trackBot(url, body) {
    try {
      url = String(url || '');
      if (url.indexOf('StudentStatus') > -1 && typeof body === 'string') {
        var b = JSON.parse(body);
        if (b && typeof b.bot_on === 'boolean') {
          if (b.bot_on) { lastSeen = Date.now(); setBot(true); } else { setBot(false); }
        }
      }
    } catch (e) {}
  }
  setInterval(function () {
    if (botOn && Date.now() - lastSeen > 75000) setBot(false);
  }, 5000);


  // 4) Console snapshot for the native floating console (read from the page).
  var hiddenApp = false, lastSnap = '';
  function txt(root, sel) {
    var e = root.querySelector(sel);
    return e ? String(e.textContent || '').trim() : '';
  }
  function cls1(el, re, def) {
    var m = re.exec(el ? String(el.className) : '');
    return m ? m[1] : def;
  }
  function snap(force) {
    try {
      var sheet = document.querySelector('.lcx-sheet');
      if (!sheet) {
        // the page keeps the console closed: press its own bubble to open it
        var b = document.querySelector('.float-bubble');
        if (b && String(b.className).indexOf('docked') < 0) b.click();
        return;
      }
      var link = sheet.querySelector('.lcx-link');
      var cards = sheet.querySelectorAll('.lhf-card');
      var items = [];
      for (var i = 0; i < cards.length; i++) {
        var c = cards[i];
        items.push({
          tone: cls1(c, /\bt-(\w+)/, 'idle'),
          title: txt(c, '.lhf-name'),
          detail: txt(c, '.lhf-sub'),
          ts: txt(c, '.lhf-ts'),
          sym: txt(c, '.lhf-sym')
        });
      }
      var data = JSON.stringify({
        name: txt(sheet, '.lcx-name'),
        state: txt(sheet, '.lcx-state'),
        stateCls: cls1(sheet, /\b(exec|mon|ana)\b/, 'ana'),
        linkTitle: txt(sheet, '.lcx-link-title'),
        linkSub: txt(sheet, '.lcx-link-sub'),
        badge: txt(sheet, '.lcx-badge'),
        linkCls: cls1(link, /\b(on|off|checking)\b/, 'off'),
        picture: (function () { var im = sheet.querySelector('.lcx-avatar img'); return im ? String(im.src || '') : ''; })(),
        items: items
      });
      if (force || data !== lastSnap) {
        lastSnap = data;
        window.AndroidNotify.consoleData(data);
      }
    } catch (e) {}
  }
  window.__lhSetHidden = function (h) {
    hiddenApp = !!h;
    if (hiddenApp && botOn) snap(true);
  };
  window.__lhSnap = function () { snap(true); };
  setInterval(function () { if (botOn) snap(false); }, 1000);


  // 5) Use the bot picture on the page's own bubble (same picture as the floating one).
  var botPic = 'https://media.base44.com/images/public/6aa67a9e1184705e502a809d/688d3676b_file_00000000f32481f5836d322f13f13271.png';
  function ensureBubbleStyle() {
    try {
      if (window.AndroidNotify && document.documentElement) document.documentElement.classList.add('lh-native');
      if (document.getElementById('lh-bubble-style')) return;
      var st = document.createElement('style');
      st.id = 'lh-bubble-style';
      st.textContent = '.float-bubble img{width:100%;height:100%;object-fit:cover;border-radius:50%}'
        + 'html.lh-native .float-bubble,html.lh-native .lcx-sheet{display:none!important}';
      (document.head || document.documentElement).appendChild(st);
    } catch (e) {}
  }
  setInterval(function () {
    try {
      ensureBubbleStyle();
      var av = document.querySelector('.lcx-avatar img');
      if (av && av.src) botPic = av.src;
      var ims = document.querySelectorAll('.float-bubble img');
      for (var i = 0; i < ims.length; i++) {
        if (ims[i].src !== botPic) ims[i].src = botPic;
      }
    } catch (e) {}
  }, 1000);


  // 6) Background watch while the bot is OFF: replay the page's last signal request
  //    so new signals still notify the user, who can then turn the bot ON.
  var lastReq = null;
  function setReq(r) {
    lastReq = r;
    try { localStorage.setItem('lh_sigreq', JSON.stringify(r)); } catch (e) {}
  }
  try {
    var saved = localStorage.getItem('lh_sigreq');
    if (saved) lastReq = JSON.parse(saved);
  } catch (e) {}
  function plainHeaders(h) {
    if (!h) return {};
    if (typeof h.forEach === 'function' && !Array.isArray(h)) {
      var o = {};
      h.forEach(function (v, k) { o[k] = v; });
      return o;
    }
    return h;
  }
  function replay() {
    if (botOn || !lastReq) return;
    try {
      if (lastReq.xhr) {
        var x = new XMLHttpRequest();
        x.open(lastReq.method, lastReq.url);
        for (var k in lastReq.headers) x.setRequestHeader(k, lastReq.headers[k]);
        x.send();
      } else if (window.fetch) {
        window.fetch(lastReq.url, lastReq.init).catch(function () {});
      }
    } catch (e) {}
  }
  setInterval(replay, 20000);

  // XMLHttpRequest (axios)
  try {
    var oOpen = XMLHttpRequest.prototype.open;
    var oSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function (m, u) {
      this.__lhUrl = String(u);
      this.__lhM = String(m || 'GET');
      this.__lhH = {};
      return oOpen.apply(this, arguments);
    };
    var oSetH = XMLHttpRequest.prototype.setRequestHeader;
    XMLHttpRequest.prototype.setRequestHeader = function (k, v) {
      (this.__lhH = this.__lhH || {})[k] = v;
      return oSetH.apply(this, arguments);
    };
    XMLHttpRequest.prototype.send = function () {
      var x = this;
      trackBot(x.__lhUrl, arguments[0]);
      if (x.__lhUrl && x.__lhUrl.indexOf('EaSignal') > -1 && isEventUrl(x.__lhUrl)) {
        setReq({ xhr: true, method: x.__lhM || 'GET', url: x.__lhUrl, headers: x.__lhH || {} });
      }
      if (x.__lhUrl && x.__lhUrl.indexOf('EaSignal') > -1) {
        x.addEventListener('load', function () {
          try {
            var d = (x.responseType === '' || x.responseType === 'text') ? x.responseText : x.response;
            parse(d, x.__lhUrl);
          } catch (e) {}
        });
      }
      return oSend.apply(this, arguments);
    };
  } catch (e) {}

  // fetch
  try {
    var oFetch = window.fetch;
    if (oFetch) {
      window.fetch = function (input, init) {
        var url = typeof input === 'string' ? input : (input && input.url) || '';
        trackBot(url, init && init.body);
        if (url.indexOf('EaSignal') > -1 && isEventUrl(url) && !(init && init.body)) {
          var ini = {};
          if (init) { for (var key in init) { if (key !== 'signal') ini[key] = init[key]; } }
          ini.headers = plainHeaders(init && init.headers);
          setReq({ xhr: false, url: url, init: ini });
        }
        var p = oFetch.apply(this, arguments);
        if (url.indexOf('EaSignal') > -1) {
          p.then(function (r) {
            try { r.clone().json().then(function (d) { parse(d, url); }).catch(function () {}); } catch (e) {}
          }).catch(function () {});
        }
        return p;
      };
    }
  } catch (e) {}
})();
