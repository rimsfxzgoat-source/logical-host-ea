package com.logicalhost.app;

import android.content.Context;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * The Bot Console as a floating card over other apps.
 * Same look as the web console (lh-console2.css): dark card, blue edge,
 * hero with the bot picture, SELF-HOST PC link card and LIVE ACTIVITY feed.
 */
public class ConsolePanel {

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    // colours from the web console CSS
    private static final int BLUE = 0xFF4D80FF;
    private static final int BLUE_BRIGHT = 0xFF7AA2FF;
    private static final int GREEN = 0xFF3DDC84;
    private static final int RED = 0xFFEF4B4B;
    private static final int ORANGE = 0xFFFFB454;
    private static final int MUTED = 0xFF8FA3C8;
    private static final int MUTED2 = 0xFF5F6F94;
    private static final int WHITE = 0xFFFFFFFF;

    private final Context ctx;
    private final WindowManager wm;
    private final float d;

    private LinearLayout root;
    private WindowManager.LayoutParams wlp;
    private ImageView avatar;
    private TextView nameTv, stateTv, linkTitleTv, linkSubTv, badgeTv, countTv;
    private LinearLayout heroCard, linkCard, list;
    private boolean shown = false;
    private String lastJson = "";
    private int posX = Integer.MIN_VALUE;
    private int posY = Integer.MIN_VALUE;

    ConsolePanel(Context c) {
        ctx = c;
        wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
        d = c.getResources().getDisplayMetrics().density;
    }

    boolean isShown() {
        return shown;
    }

    void show() {
        if (shown || !Settings.canDrawOverlays(ctx)) return;
        build();
        try {
            wm.addView(root, wlp);
            shown = true;
        } catch (Exception e) {
            shown = false;
            root = null;
            return;
        }
        if (!lastJson.isEmpty()) render(lastJson);
        WebHost.requestSnapshot();
    }

    void hide() {
        if (!shown) return;
        try {
            wm.removeView(root);
        } catch (Exception ignored) {
        }
        shown = false;
        root = null;
    }

    void update(String json) {
        lastJson = json;
        if (shown) render(json);
    }

    void refreshPicture() {
        if (shown) paintPicture();
    }

    // ------------------------------------------------------------ helpers

    private int dp(float v) {
        return (int) (v * d + 0.5f);
    }

    private int alpha(int color, float a) {
        return (color & 0x00FFFFFF) | (((int) (a * 255f)) << 24);
    }

    private GradientDrawable box(int fill, float radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private GradientDrawable gradient(int[] colors, int orientationIndex, float radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable(
                orientationIndex == 0 ? GradientDrawable.Orientation.TOP_BOTTOM
                        : GradientDrawable.Orientation.TL_BR, colors);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private TextView tv(String text, float sp, int color, boolean bold) {
        TextView t = new TextView(ctx);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView pill(int color) {
        TextView t = tv("", 9.5f, color, true);
        t.setLetterSpacing(0.14f);
        t.setPadding(dp(10), dp(5), dp(10), dp(5));
        return t;
    }

    private TextView button(String label) {
        TextView t = tv(label, 10, BLUE_BRIGHT, true);
        t.setLetterSpacing(0.1f);
        t.setPadding(dp(10), dp(6), dp(10), dp(6));
        t.setBackground(box(alpha(BLUE, 0.06f), 10, alpha(BLUE, 0.35f)));
        return t;
    }

    private LinearLayout.LayoutParams lp(int w, int h, float weight, int top, int left, int right) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h, weight);
        p.topMargin = dp(top);
        p.leftMargin = dp(left);
        p.rightMargin = dp(right);
        return p;
    }

    // -------------------------------------------------------------- build

    private void build() {
        int sw = ctx.getResources().getDisplayMetrics().widthPixels;
        int sh = ctx.getResources().getDisplayMetrics().heightPixels;
        int w = Math.min((int) (sw * 0.92f), dp(420));
        int h = (int) (sh * 0.72f);

        root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(gradient(new int[]{0xF50C1228, 0xFC050814}, 0,
                22, alpha(BLUE, 0.35f)));
        root.setClipToOutline(true);
        root.setOutlineProvider(ViewOutlineProvider.BACKGROUND);

        // top: grip (drag here) and close button
        FrameLayout head = new FrameLayout(ctx);
        View grip = new View(ctx);
        grip.setBackground(box(0x29FFFFFF, 2, 0));
        FrameLayout.LayoutParams gp = new FrameLayout.LayoutParams(dp(44), dp(4),
                Gravity.CENTER_HORIZONTAL | Gravity.TOP);
        gp.topMargin = dp(12);
        head.addView(grip, gp);
        TextView close = tv("\u2715", 13, MUTED, true);
        close.setGravity(Gravity.CENTER);
        close.setBackground(box(0xE6050A18, 10, alpha(BLUE, 0.35f)));
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(dp(30), dp(30),
                Gravity.END | Gravity.TOP);
        cp.topMargin = dp(12);
        cp.rightMargin = dp(12);
        head.addView(close, cp);
        close.setOnClickListener(v -> {
            KeepAliveService s = KeepAliveService.instance;
            if (s != null) s.hidePanel();
        });
        root.addView(head, new LinearLayout.LayoutParams(MATCH, dp(44)));
        drag(head);

        LinearLayout body = new LinearLayout(ctx);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(0, 0, 0, dp(12));

        // hero card
        heroCard = new LinearLayout(ctx);
        heroCard.setOrientation(LinearLayout.HORIZONTAL);
        heroCard.setGravity(Gravity.CENTER_VERTICAL);
        heroCard.setPadding(dp(14), dp(14), dp(14), dp(14));
        heroCard.setBackground(gradient(new int[]{alpha(BLUE, 0.16f), alpha(BLUE, 0.03f)}, 1,
                18, alpha(BLUE, 0.25f)));
        avatar = new ImageView(ctx);
        avatar.setBackgroundResource(R.drawable.bubble_bg);
        avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
        avatar.setClipToOutline(true);
        avatar.setOutlineProvider(ViewOutlineProvider.BACKGROUND);
        paintPicture();
        heroCard.addView(avatar, new LinearLayout.LayoutParams(dp(80), dp(80)));

        LinearLayout idCol = new LinearLayout(ctx);
        idCol.setOrientation(LinearLayout.VERTICAL);
        TextView kicker = tv("BOT CONSOLE", 9.5f, BLUE_BRIGHT, true);
        kicker.setLetterSpacing(0.22f);
        nameTv = tv("BOT", 20, WHITE, true);
        nameTv.setSingleLine(true);
        nameTv.setEllipsize(TextUtils.TruncateAt.END);
        stateTv = pill(BLUE_BRIGHT);
        idCol.addView(kicker);
        idCol.addView(nameTv, lp(WRAP, WRAP, 0, 3, 0, 0));
        idCol.addView(stateTv, lp(WRAP, WRAP, 0, 8, 0, 0));
        heroCard.addView(idCol, new LinearLayout.LayoutParams(0, WRAP, 1f));
        ((LinearLayout.LayoutParams) heroCard.getChildAt(1).getLayoutParams()).leftMargin = dp(16);
        body.addView(heroCard, lp(MATCH, WRAP, 0, 16, 16, 16));

        // SELF-HOST PC link card
        linkCard = new LinearLayout(ctx);
        linkCard.setOrientation(LinearLayout.HORIZONTAL);
        linkCard.setGravity(Gravity.CENTER_VERTICAL);
        linkCard.setPadding(dp(14), dp(12), dp(14), dp(12));
        linkCard.setBackground(gradient(new int[]{alpha(RED, 0.06f), alpha(RED, 0.06f)}, 0,
                16, alpha(RED, 0.35f)));
        TextView linkIcon = tv("PC", 11, RED, true);
        linkIcon.setGravity(Gravity.CENTER);
        linkIcon.setBackground(box(0x0AFFFFFF, 12, 0x14FFFFFF));
        linkCard.addView(linkIcon, new LinearLayout.LayoutParams(dp(38), dp(38)));
        LinearLayout linkText = new LinearLayout(ctx);
        linkText.setOrientation(LinearLayout.VERTICAL);
        linkTitleTv = tv("SELF-HOST PC", 11, WHITE, true);
        linkTitleTv.setLetterSpacing(0.16f);
        linkSubTv = tv("", 10.5f, MUTED, false);
        linkSubTv.setSingleLine(true);
        linkSubTv.setEllipsize(TextUtils.TruncateAt.END);
        linkText.addView(linkTitleTv);
        linkText.addView(linkSubTv, lp(WRAP, WRAP, 0, 3, 0, 0));
        LinearLayout.LayoutParams ltp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        ltp.leftMargin = dp(12);
        linkCard.addView(linkText, ltp);
        badgeTv = tv("", 12, RED, true);
        badgeTv.setLetterSpacing(0.14f);
        badgeTv.setPadding(dp(13), dp(7), dp(13), dp(7));
        linkCard.addView(badgeTv);
        body.addView(linkCard, lp(MATCH, WRAP, 0, 10, 16, 16));

        // LIVE ACTIVITY
        LinearLayout act = new LinearLayout(ctx);
        act.setOrientation(LinearLayout.HORIZONTAL);
        act.setGravity(Gravity.CENTER_VERTICAL);
        View liveDot = new View(ctx);
        liveDot.setBackground(box(BLUE_BRIGHT, 4, 0));
        act.addView(liveDot, new LinearLayout.LayoutParams(dp(7), dp(7)));
        TextView actT = tv("LIVE ACTIVITY", 10.5f, WHITE, true);
        actT.setLetterSpacing(0.14f);
        LinearLayout.LayoutParams atp = new LinearLayout.LayoutParams(WRAP, WRAP);
        atp.leftMargin = dp(8);
        act.addView(actT, atp);
        countTv = tv("0", 10, BLUE_BRIGHT, true);
        countTv.setPadding(dp(8), dp(2), dp(8), dp(2));
        countTv.setBackground(box(alpha(BLUE, 0.15f), 20, 0));
        LinearLayout.LayoutParams ctp = new LinearLayout.LayoutParams(WRAP, WRAP);
        ctp.leftMargin = dp(8);
        act.addView(countTv, ctp);
        act.addView(new View(ctx), new LinearLayout.LayoutParams(0, 1, 1f));
        TextView clear = button("CLEAR");
        clear.setOnClickListener(v -> WebHost.clickInPage(".lhf-actions button"));
        act.addView(clear);
        TextView open = button("OPEN APP");
        open.setOnClickListener(v -> {
            KeepAliveService s = KeepAliveService.instance;
            if (s != null) s.openApp();
        });
        LinearLayout.LayoutParams opp = new LinearLayout.LayoutParams(WRAP, WRAP);
        opp.leftMargin = dp(6);
        act.addView(open, opp);
        body.addView(act, lp(MATCH, WRAP, 0, 14, 18, 18));

        list = new LinearLayout(ctx);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(8), dp(8), dp(8), dp(8));
        list.setBackground(gradient(new int[]{alpha(0xFF040712, 0.85f), alpha(0xFF040712, 0.85f)}, 0,
                14, alpha(BLUE, 0.22f)));
        body.addView(list, lp(MATCH, WRAP, 0, 8, 16, 16));

        ScrollView scroll = new ScrollView(ctx);
        scroll.addView(body, new ViewGroup.LayoutParams(MATCH, WRAP));
        root.addView(scroll, new LinearLayout.LayoutParams(MATCH, 0, 1f));

        wlp = new WindowManager.LayoutParams(
                w, h,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        wlp.gravity = Gravity.TOP | Gravity.START;
        wlp.x = posX == Integer.MIN_VALUE ? (sw - w) / 2 : posX;
        wlp.y = posY == Integer.MIN_VALUE ? (int) (sh * 0.14f) : posY;
    }

    private void paintPicture() {
        if (avatar == null) return;
        if (BotPicture.bitmap != null) {
            avatar.setImageBitmap(BotPicture.bitmap);
        } else {
            avatar.setImageResource(R.drawable.bot_picture);
        }
    }

    private void drag(View handle) {
        handle.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy;
            float tx, ty;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = wlp.x;
                        sy = wlp.y;
                        tx = e.getRawX();
                        ty = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        wlp.x = sx + (int) (e.getRawX() - tx);
                        wlp.y = sy + (int) (e.getRawY() - ty);
                        posX = wlp.x;
                        posY = wlp.y;
                        try {
                            wm.updateViewLayout(root, wlp);
                        } catch (Exception ignored) {
                        }
                        return true;
                    default:
                        return true;
                }
            }
        });
    }

    // ------------------------------------------------------------- render

    private void render(String json) {
        if (root == null) return;
        try {
            JSONObject o = new JSONObject(json);

            if (o.has("picture")) BotPicture.use(ctx, o.optString("picture", ""));

            nameTv.setText(o.optString("name", "BOT"));

            String cls = o.optString("stateCls", "ana");
            int sc = "exec".equals(cls) ? ORANGE : "mon".equals(cls) ? GREEN : BLUE_BRIGHT;
            String st = o.optString("state", "");
            stateTv.setText(st.isEmpty() ? "WAITING FOR MENTOR SIGNAL" : st);
            stateTv.setTextColor(sc);
            stateTv.setBackground(box(alpha(sc, 0.12f), 999, alpha(sc, 0.45f)));

            String lc = o.optString("linkCls", "off");
            int lcol = "on".equals(lc) ? GREEN : "off".equals(lc) ? RED : BLUE_BRIGHT;
            linkCard.setBackground(gradient(new int[]{alpha(lcol, 0.08f), alpha(lcol, 0.08f)}, 0,
                    16, alpha(lcol, 0.35f)));
            linkTitleTv.setText(o.optString("linkTitle", "SELF-HOST PC"));
            linkSubTv.setText(o.optString("linkSub", ""));
            String badge = o.optString("badge", "");
            badgeTv.setText("\u25CF " + (badge.isEmpty() ? lc.toUpperCase() : badge));
            badgeTv.setTextColor(lcol);
            badgeTv.setBackground(box(alpha(lcol, 0.12f), 10, alpha(lcol, 0.45f)));

            JSONArray items = o.optJSONArray("items");
            int n = items == null ? 0 : items.length();
            countTv.setText(String.valueOf(n));
            list.removeAllViews();
            if (n == 0) {
                list.addView(card("idle", "Waiting for signal",
                        "Bot activity will show here", "", ""), lp(MATCH, WRAP, 0, 0, 0, 0));
            } else {
                for (int i = 0; i < n; i++) {
                    JSONObject it = items.getJSONObject(i);
                    list.addView(card(it.optString("tone", "idle"), it.optString("title"),
                            it.optString("detail"), it.optString("ts"), it.optString("sym")),
                            lp(MATCH, WRAP, 0, i == 0 ? 0 : 8, 0, 0));
                }
            }
        } catch (Exception ignored) {
        }
    }

    private View card(String tone, String title, String detail, String ts, String sym) {
        int tc = "ok".equals(tone) ? GREEN
                : "err".equals(tone) ? RED
                : "warn".equals(tone) ? ORANGE
                : "idle".equals(tone) ? MUTED2 : BLUE_BRIGHT;

        LinearLayout c = new LinearLayout(ctx);
        c.setOrientation(LinearLayout.HORIZONTAL);
        c.setBackground(box(0xFF0F1630, 14, alpha(BLUE, 0.12f)));

        View bar = new View(ctx);
        bar.setBackground(box(tc, 2, 0));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(4), MATCH);
        bp.setMargins(dp(8), dp(8), 0, dp(8));
        c.addView(bar, bp);

        LinearLayout text = new LinearLayout(ctx);
        text.setOrientation(LinearLayout.VERTICAL);
        text.setPadding(dp(12), dp(10), dp(8), dp(10));
        text.addView(tv(title, 14, WHITE, true));
        if (!detail.isEmpty()) text.addView(tv(detail, 12, MUTED, false));
        c.addView(text, new LinearLayout.LayoutParams(0, WRAP, 1f));

        LinearLayout right = new LinearLayout(ctx);
        right.setOrientation(LinearLayout.VERTICAL);
        right.setGravity(Gravity.END);
        right.setPadding(0, dp(10), dp(12), dp(10));
        if (!ts.isEmpty()) {
            TextView t = tv(ts, 11, 0xFF7F89B0, false);
            t.setTypeface(Typeface.MONOSPACE);
            right.addView(t);
        }
        if (!sym.isEmpty()) right.addView(tv(sym, 10.5f, BLUE_BRIGHT, true));
        c.addView(right, new LinearLayout.LayoutParams(WRAP, WRAP));
        return c;
    }
}
