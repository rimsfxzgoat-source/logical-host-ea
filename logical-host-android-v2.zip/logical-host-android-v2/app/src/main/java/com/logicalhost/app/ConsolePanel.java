package com.logicalhost.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * The floating bot console, drawn the same way as the web console (RunPanel, iOS style):
 * the bot picture as the hero with the name and the close button, the EXPAND / MORE live activity,
 * the activity rows, and the "Powered by Logical Host" footer.
 */
class ConsolePanel {

    // colours of the web console
    private static final int CARD = 0xDB081120;        // #081120 at 86%
    private static final int CARD_EDGE = 0x4D7EA6FF;   // blue edge
    private static final int HERO_BG = 0xFF0C1830;
    private static final int INK = 0xFFDFE6F5;
    private static final int INK_DIM = 0xFF6C7BA0;
    private static final int ACCENT = 0xFF7EA6FF;
    private static final int MORE = 0xFF47679F;
    private static final int BTN_TEXT = 0xFF9FB2D9;
    private static final int OK = 0xFF57D38A;
    private static final int ERR = 0xFFFF8A5C;
    private static final int WARN = 0xFFFFC46B;
    private static final int POWERED = 0xFF8EA0C4;

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private final Context ctx;
    private final WindowManager wm;
    private final float d;

    private LinearLayout root;
    private FrameLayout frame;
    private WindowManager.LayoutParams wlp;
    private ImageView heroImg;
    private TextView nameTv;
    private LinearLayout expandBar, body, moreBtn, footer, list;
    private ScrollView feedScroll;
    private TextView moreLabel, moreCount;
    private boolean feedOpen = false;
    private boolean shown = false;
    private String lastJson = "";
    private int posX = Integer.MIN_VALUE;
    private int posY = Integer.MIN_VALUE;

    ConsolePanel(Context c) {
        ctx = c;
        wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
        d = c.getResources().getDisplayMetrics().density;
    }

    boolean isShown() {
        return shown;
    }

    void show() {
        if (shown || !android.provider.Settings.canDrawOverlays(ctx)) return;
        build();
        try {
            wm.addView(frame, wlp);
            shown = true;
        } catch (Exception e) {
            shown = false;
            root = null;
            frame = null;
            return;
        }
        if (!lastJson.isEmpty()) render(lastJson);
        WebHost.requestSnapshot();
    }

    void hide() {
        if (!shown || frame == null) return;
        try {
            wm.removeView(frame);
        } catch (Exception ignored) {
        }
        frame = null;
        root = null;
        shown = false;
    }

    void update(String json) {
        lastJson = json;
        if (shown) render(json);
    }

    void refreshPicture() {
        try {
            if (shown) paintPicture();
        } catch (Throwable t) {
            android.util.Log.e("LogicalHost", "console picture not refreshed", t);
        }
    }

    // ------------------------------------------------------------ helpers

    private int dp(float v) {
        return (int) (v * d + 0.5f);
    }

    private static int alpha(int color, float a) {
        return (color & 0x00FFFFFF) | (((int) (a * 255f)) << 24);
    }

    private GradientDrawable box(int fill, float radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != 0) g.setStroke(dp(0.5f), stroke);
        return g;
    }

    private TextView tv(String text, float sp, int color, boolean bold) {
        TextView t = new TextView(ctx);
        t.setText(text);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        t.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        return t;
    }

    private LinearLayout.LayoutParams lp(int w, int h, float weight, int top, int left, int right) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h, weight);
        p.topMargin = dp(top);
        p.leftMargin = dp(left);
        p.rightMargin = dp(right);
        return p;
    }

    private View dot(int color, int sizeDp) {
        View v = new View(ctx);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        v.setBackground(g);
        return v;
    }

    // ------------------------------------------------------------- build

    private void build() {
        int screenW = ctx.getResources().getDisplayMetrics().widthPixels;
        int w = Math.min(dp(320), screenW - dp(32));

        root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(box(CARD, 28, CARD_EDGE));
        root.setClipToOutline(true);
        root.setOutlineProvider(android.view.ViewOutlineProvider.BACKGROUND);

        // hero: the bot picture, the name over it, the close button
        FrameLayout hero = new FrameLayout(ctx);
        hero.setClipToOutline(true);
        hero.setOutlineProvider(android.view.ViewOutlineProvider.BACKGROUND);
        hero.setBackground(box(HERO_BG, 22, 0));
        heroImg = new ImageView(ctx);
        heroImg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        hero.addView(heroImg, new FrameLayout.LayoutParams(MATCH, MATCH));
        View shade = new View(ctx);
        shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x00040A16, 0xC8040A16}));
        hero.addView(shade, new FrameLayout.LayoutParams(MATCH, MATCH));

        nameTv = tv("BOT", 22, 0xFFFFFFFF, true);
        nameTv.setSingleLine(true);
        nameTv.setEllipsize(TextUtils.TruncateAt.END);
        nameTv.setShadowLayer(dp(6), 0, dp(2), 0xA6000000);
        FrameLayout.LayoutParams np = new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.START | Gravity.BOTTOM);
        np.leftMargin = dp(16);
        np.bottomMargin = dp(12);
        np.rightMargin = dp(60);
        hero.addView(nameTv, np);

        TextView close = tv("\u2715", 13, 0xFFFFFFFF, true);
        close.setGravity(Gravity.CENTER);
        close.setBackground(box(0x8C080E1A, 16, 0));
        close.setOnClickListener(v -> {
            KeepAliveService s = KeepAliveService.instance;
            if (s != null) s.hidePanel();
        });
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(dp(32), dp(32), Gravity.END | Gravity.TOP);
        cp.topMargin = dp(12);
        cp.rightMargin = dp(12);
        hero.addView(close, cp);

        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(MATCH, dp(180));
        hp.leftMargin = dp(8);
        hp.rightMargin = dp(8);
        hp.topMargin = dp(8);
        root.addView(hero, hp);
        // EXPAND bar (shown when the console is folded)
        expandBar = new LinearLayout(ctx);
        expandBar.setGravity(Gravity.CENTER);
        expandBar.setBackground(box(0x1A7EA6FF, 16, 0));
        TextView exp = tv("EXPAND \u25BE", 12, ACCENT, true);
        exp.setLetterSpacing(0.14f);
        expandBar.addView(exp);
        expandBar.setOnClickListener(v -> toggleFeed());
        root.addView(expandBar, lp(MATCH, dp(44), 0, 8, 8, 8));

        // body (shown when the console is open): MORE / live activity, CLEAR, ALL LOGS
        body = new LinearLayout(ctx);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(14), dp(4), dp(12), dp(2));
        body.setBackground(box(0x0AFFFFFF, 18, 0));

        moreBtn = new LinearLayout(ctx);
        moreBtn.setOrientation(LinearLayout.HORIZONTAL);
        moreBtn.setGravity(Gravity.CENTER_VERTICAL);
        moreBtn.setPadding(0, dp(8), 0, dp(8));
        moreLabel = tv("LESS \u25B4", 11, MORE, true);
        moreLabel.setLetterSpacing(0.1f);
        moreCount = tv("0", 10, ACCENT, true);
        moreCount.setPadding(dp(8), dp(2), dp(8), dp(2));
        moreCount.setBackground(box(0x245F8BFF, 999, 0));
        moreBtn.addView(moreLabel);
        moreBtn.addView(moreCount, lp(WRAP, WRAP, 0, 0, 7, 0));
        moreBtn.setOnClickListener(v -> toggleFeed());
        body.addView(moreBtn, new LinearLayout.LayoutParams(MATCH, WRAP));

        list = new LinearLayout(ctx);
        list.setOrientation(LinearLayout.VERTICAL);
        feedScroll = new ScrollView(ctx);
        feedScroll.setVerticalScrollBarEnabled(false);
        feedScroll.addView(list, new FrameLayout.LayoutParams(MATCH, WRAP));
        body.addView(feedScroll, new LinearLayout.LayoutParams(MATCH, dp(200)));

        LinearLayout btns = new LinearLayout(ctx);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        TextView clear = tv("CLEAR", 10, BTN_TEXT, true);
        clear.setLetterSpacing(0.14f);
        clear.setGravity(Gravity.CENTER);
        clear.setPadding(dp(12), dp(7), dp(12), dp(7));
        clear.setBackground(box(0x145F8BFF, 8, 0x1F7896FF));
        clear.setOnClickListener(v -> WebHost.clickInPage(".bc-foot .bc-btn"));
        btns.addView(clear, lp(0, WRAP, 1f, 0, 0, 8));
        TextView all = tv("ALL LOGS", 10, BTN_TEXT, true);
        all.setLetterSpacing(0.14f);
        all.setGravity(Gravity.CENTER);
        all.setPadding(dp(12), dp(7), dp(12), dp(7));
        all.setBackground(box(0x145F8BFF, 8, 0x1F7896FF));
        all.setOnClickListener(v -> {
            KeepAliveService s = KeepAliveService.instance;
            if (s != null) s.openApp();
        });
        btns.addView(all, lp(0, WRAP, 1f, 0, 0, 0));
        body.addView(btns, lp(MATCH, WRAP, 0, 6, 0, 0));

        footer = new LinearLayout(ctx);
        footer.setOrientation(LinearLayout.VERTICAL);
        body.setVisibility(View.GONE);
        root.addView(body, lp(MATCH, WRAP, 0, 8, 8, 8));

        // "Powered by Logical Host"
        LinearLayout foot = new LinearLayout(ctx);
        foot.setGravity(Gravity.CENTER_VERTICAL);
        foot.setPadding(dp(18), dp(10), dp(12), dp(12));
        TextView powered = tv("Powered by ", 12, POWERED, false);
        foot.addView(powered);
        TextView brand = tv("Logical Host", 12, 0xFFFFFFFF, true);
        foot.addView(brand);
        root.addView(foot, new LinearLayout.LayoutParams(MATCH, WRAP));

        frame = new FrameLayout(ctx);
        frame.addView(root, new FrameLayout.LayoutParams(w, WRAP));

        wlp = new WindowManager.LayoutParams(
                w, WRAP,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                android.graphics.PixelFormat.TRANSLUCENT);
        wlp.gravity = Gravity.TOP | Gravity.START;
        if (posX == Integer.MIN_VALUE) {
            wlp.x = (screenW - w) / 2;
            wlp.y = dp(96);
        } else {
            wlp.x = posX;
            wlp.y = posY;
        }
        drag(hero, false);
        applyFolded();
        paintPicture();
    }

    // ------------------------------------------------------------ state

    private void applyFolded() {
        if (expandBar == null || body == null) return;
        expandBar.setVisibility(feedOpen ? View.GONE : View.VISIBLE);
        body.setVisibility(feedOpen ? View.VISIBLE : View.GONE);
    }

    private void toggleFeed() {
        feedOpen = !feedOpen;
        // mirror the page: EXPAND opens the page's live activity, LESS folds it again
        WebHost.clickInPage(feedOpen ? ".bcon-expand" : ".bc-more");
        applyFolded();
        if (moreLabel != null) moreLabel.setText(feedOpen ? "LESS \u25B4" : "MORE \u25BE");
    }

    private void paintPicture() {
        if (heroImg == null) return;
        Bitmap bm = BotPicture.bitmap;
        if (bm != null) heroImg.setImageBitmap(bm); else heroImg.setImageResource(R.drawable.bot_picture);
    }

    private void drag(View handle, boolean orbTap) {
        handle.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy;
            float tx, ty;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = wlp.x;
                        sy = wlp.y;
                        tx = e.getRawX();
                        ty = e.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (Math.abs(e.getRawX() - tx) > 8 || Math.abs(e.getRawY() - ty) > 8) moved = true;
                        wlp.x = sx + (int) (e.getRawX() - tx);
                        wlp.y = sy + (int) (e.getRawY() - ty);
                        posX = wlp.x;
                        posY = wlp.y;
                        try {
                            wm.updateViewLayout(frame, wlp);
                        } catch (Exception ignored) {
                        }
                        return true;
                    default:
                        return true;
                }
            }
        });
    }

    // ------------------------------------------------------------ render

    private static int toneColor(String tone) {
        if ("ok".equals(tone)) return OK;
        if ("err".equals(tone)) return ERR;
        if ("warn".equals(tone)) return WARN;
        if ("info".equals(tone)) return ACCENT;
        return ACCENT;
    }

    private void render(String json) {
        if (root == null) return;
        try {
            JSONObject o = new JSONObject(json);
            if (o.has("picture")) BotPicture.use(ctx, o.optString("picture", ""));
            nameTv.setText(o.optString("name", "BOT").toUpperCase());

            JSONArray items = o.optJSONArray("items");
            int n = items == null ? 0 : items.length();
            moreCount.setText(String.valueOf(n));
            list.removeAllViews();
            if (n == 0) {
                TextView empty = tv("", 12, INK_DIM, false);
                empty.setPadding(0, dp(12), 0, dp(12));
                list.addView(empty);
            } else {
                for (int i = 0; i < n; i++) {
                    JSONObject it = items.getJSONObject(i);
                    list.addView(row(it.optString("tone", "idle"), it.optString("title"),
                            it.optString("detail"), it.optString("ts"), it.optString("sym")));
                }
            }
        } catch (Exception ignored) {
        }
    }

    private View row(String tone, String title, String detail, String ts, String sym) {
        int tc = toneColor(tone);
        LinearLayout r = new LinearLayout(ctx);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(9), 0, dp(9));

        // the round icon (the web's bc-ico)
        FrameLayout ico = new FrameLayout(ctx);
        ico.setBackground(box(0x245F8BFF, 8, 0));
        ico.addView(dot(tc, 6), new FrameLayout.LayoutParams(dp(6), dp(6), Gravity.CENTER));
        r.addView(ico, new LinearLayout.LayoutParams(dp(26), dp(26)));

        LinearLayout text = new LinearLayout(ctx);
        text.setOrientation(LinearLayout.VERTICAL);
        TextView t = tv(title, 12, tc, true);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        text.addView(t);
        if (!detail.isEmpty()) {
            TextView s = tv(detail, 11, INK_DIM, false);
            s.setSingleLine(true);
            s.setEllipsize(TextUtils.TruncateAt.END);
            text.addView(s);
        }
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        tp.leftMargin = dp(10);
        r.addView(text, tp);

        LinearLayout meta = new LinearLayout(ctx);
        meta.setOrientation(LinearLayout.VERTICAL);
        meta.setGravity(Gravity.END);
        if (!sym.isEmpty()) {
            TextView s = tv(sym, 9, ACCENT, true);
            s.setPadding(dp(5), dp(1), dp(5), dp(1));
            s.setBackground(box(0x1F5F8BFF, 6, 0));
            meta.addView(s);
        }
        TextView tsv = tv(ts, 10, INK_DIM, false);
        meta.addView(tsv);
        r.addView(meta, new LinearLayout.LayoutParams(WRAP, WRAP));
        return r;
    }
}
