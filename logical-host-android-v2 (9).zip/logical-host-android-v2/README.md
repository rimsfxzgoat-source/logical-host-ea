# Logical Host - Android app v2

Files that matter:
- app/src/main/java/com/logicalhost/app/WebHost.java        one shared WebView (bot keeps running)
- app/src/main/java/com/logicalhost/app/MainActivity.java   the screen
- app/src/main/java/com/logicalhost/app/KeepAliveService.java  background service + floating bubble
- app/src/main/java/com/logicalhost/app/NotifyBridge.java   Android notifications
- app/src/main/assets/bridge.js                             connects the web app to notifications

Change the page the app opens: HOME_URL in WebHost.java.

Website download link (always newest):
https://github.com/YOUR-NAME/YOUR-REPO/releases/latest/download/LogicalHost.apk
