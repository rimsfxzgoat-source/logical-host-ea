package com.logicalhost.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Map;

/** Receives push messages from Base44 (FCM) and shows them right away. */
public class MessagingService extends FirebaseMessagingService {

    static final String PREFS = "lh_push";
    static final String CHANNEL = "push_signals";

    @Override
    public void onNewToken(String token) {
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("token", token).apply();
    }

    @Override
    public void onMessageReceived(RemoteMessage msg) {
        String title = "Logical Host";
        String body = "";
        if (msg.getNotification() != null) {
            if (msg.getNotification().getTitle() != null) title = msg.getNotification().getTitle();
            if (msg.getNotification().getBody() != null) body = msg.getNotification().getBody();
        }
        Map<String, String> d = msg.getData();
        if (d.containsKey("title")) title = d.get("title");
        if (d.containsKey("body")) body = d.get("body");
        show(this, title, body);
    }

    /** Token saved on the phone, so the web page can save it in Base44. */
    static String token(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("token", "");
    }

    static void show(Context c, String title, String body) {
        try {
            NotificationManager nm = c.getSystemService(NotificationManager.class);
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL, "Signals (push)", NotificationManager.IMPORTANCE_HIGH);
            ch.enableVibration(true);
            nm.createNotificationChannel(ch);
            PendingIntent pi = PendingIntent.getActivity(c, 0,
                    new Intent(c, MainActivity.class),
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification n = new NotificationCompat.Builder(c, CHANNEL)
                    .setSmallIcon(R.drawable.ic_notif)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                    .setAutoCancel(true)
                    .setContentIntent(pi)
                    .build();
            NotificationManagerCompat nmc = NotificationManagerCompat.from(c);
            if (nmc.areNotificationsEnabled()) {
                nmc.notify((int) (System.currentTimeMillis() % 100000), n);
            }
        } catch (SecurityException ignored) {
        }
    }
}
