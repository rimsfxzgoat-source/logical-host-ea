package com.logicalhost.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import java.util.Calendar;

/** Scheduled bot start: saved time, alarms, and the start itself. */
final class Schedule {

    static final String PREFS = "lh_sched";
    static final String ACTION_PRE = "com.logicalhost.app.SCHED_PRE";
    static final String ACTION_START = "com.logicalhost.app.SCHED_START";
    private static final int CODE_PRE = 101;
    private static final int CODE_START = 102;
    private static final String CHANNEL = "signals";

    private Schedule() {}

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /** Save the schedule from the web settings page and set the alarms. */
    static void save(Context c, boolean enabled, int hour, int minute, boolean auto, int lead) {
        sp(c).edit()
                .putBoolean("enabled", enabled)
                .putInt("hour", hour)
                .putInt("minute", minute)
                .putBoolean("auto", auto)
                .putInt("lead", lead)
                .putInt("tries", 0)
                .apply();
        arm(c);
    }

    /** Set the alarms for the next start (and the early warning, if any). */
    static void arm(Context c) {
        SharedPreferences p = sp(c);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        cancel(c, am, ACTION_PRE, CODE_PRE);
        cancel(c, am, ACTION_START, CODE_START);
        if (!p.getBoolean("enabled", false)) return;

        long start = next(p.getInt("hour", 0), p.getInt("minute", 0));
        int lead = p.getInt("lead", 0);
        if (lead > 0) set(c, am, start - lead * 60000L, ACTION_PRE, CODE_PRE);
        set(c, am, start, ACTION_START, CODE_START);
    }

    private static long next(int hour, int minute) {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, hour);
        cal.set(Calendar.MINUTE, minute);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        if (cal.getTimeInMillis() <= System.currentTimeMillis() + 1000) {
            cal.add(Calendar.DAY_OF_MONTH, 1);
        }
        return cal.getTimeInMillis();
    }

    private static void set(Context c, AlarmManager am, long at, String action, int code) {
        if (at <= System.currentTimeMillis()) return;
        Intent i = new Intent(c, ScheduleReceiver.class).setAction(action);
        PendingIntent pi = PendingIntent.getBroadcast(c, code, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            return;
        }
        try {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        }
    }

    private static void cancel(Context c, AlarmManager am, String action, int code) {
        Intent i = new Intent(c, ScheduleReceiver.class).setAction(action);
        PendingIntent pi = PendingIntent.getBroadcast(c, code, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_NO_CREATE);
        if (pi != null) {
            am.cancel(pi);
            pi.cancel();
        }
    }

    /** The early warning, shown before the start time. */
    static void onPre(Context c) {
        SharedPreferences p = sp(c);
        if (!p.getBoolean("enabled", false)) return;
        int lead = p.getInt("lead", 0);
        String time = String.format("%02d:%02d", p.getInt("hour", 0), p.getInt("minute", 0));
        say(c, "Bot starts soon",
                "Bot will " + (p.getBoolean("auto", true) ? "turn ON" : "be ready to start")
                        + " at " + time + " (in " + lead + " min).");
    }

    /** The scheduled time: start the bot, or just remind the user. */
    static void onStart(Context c) {
        SharedPreferences p = sp(c);
        if (!p.getBoolean("enabled", false)) return;
        if (!p.getBoolean("auto", true)) {
            say(c, "Time to trade", "Open Logical Host and turn the bot ON.");
        } else {
            p.edit().putInt("tries", 0).apply();
            tryStart(c);
        }
        arm(c);
    }

    private static void tryStart(Context c) {
        try {
            c.startForegroundService(new Intent(c, KeepAliveService.class));
        } catch (Exception ignored) {
        }
        new Handler(Looper.getMainLooper()).postDelayed(() ->
                WebHost.startBot(c, result -> {
                    if ("true".equals(result)) {
                        say(c, "Bot ON", "The bot started at the scheduled time.");
                    } else {
                        retry(c);
                    }
                }), 4000);
    }

    private static void retry(Context c) {
        SharedPreferences p = sp(c);
        int tries = p.getInt("tries", 0) + 1;
        p.edit().putInt("tries", tries).apply();
        if (tries > 10) {
            say(c, "Bot not started",
                    "The scheduled start failed (check the internet). Open the app and turn the bot ON.");
            return;
        }
        new Handler(Looper.getMainLooper()).postDelayed(() -> tryStart(c), 60000);
    }

    private static void say(Context c, String title, String body) {
        try {
            NotificationManager nm = c.getSystemService(NotificationManager.class);
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL, "Signals", NotificationManager.IMPORTANCE_HIGH);
            nm.createNotificationChannel(ch);
            PendingIntent pi = PendingIntent.getActivity(c, 0,
                    new Intent(c, MainActivity.class),
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification n = new NotificationCompat.Builder(c, CHANNEL)
                    .setSmallIcon(R.drawable.ic_notif)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setAutoCancel(true)
                    .setContentIntent(pi)
                    .build();
            NotificationManagerCompat nmc = NotificationManagerCompat.from(c);
            if (nmc.areNotificationsEnabled()) {
                nmc.notify((int) (System.currentTimeMillis() % 100000), n);
            }
        } catch (SecurityException ignored) {
        }
    }
}
