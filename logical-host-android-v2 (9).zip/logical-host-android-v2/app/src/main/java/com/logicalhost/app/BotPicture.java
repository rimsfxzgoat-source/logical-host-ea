package com.logicalhost.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** The picture of the bot, used on the bubble and in the floating console. */
final class BotPicture {

    static final String DEFAULT_URL =
            "https://media.base44.com/images/public/6aa67a9e1184705e502a809d/688d3676b_file_00000000f32481f5836d322f13f13271.png";

    static volatile Bitmap bitmap;   // null = use the built-in picture
    static Runnable onChange;        // called on the main thread when a new picture is ready

    private static String currentUrl = "";
    private static boolean loading = false;

    private BotPicture() {}

    /** Load the saved picture from the phone (fast, no internet). */
    static void init(Context c) {
        if (bitmap != null) return;
        try {
            File f = new File(c.getFilesDir(), "bot_pic_live.png");
            if (f.exists()) bitmap = BitmapFactory.decodeFile(f.getPath());
            currentUrl = c.getSharedPreferences("lh", Context.MODE_PRIVATE)
                    .getString("pic_url", "");
        } catch (Exception ignored) {
        }
    }

    /** Make sure the picture of this address is loaded. Downloads it if it is new. */
    static synchronized void use(Context c, String url) {
        if (url == null || url.isEmpty()) return;   // only the bot's own picture is used
        if (!url.startsWith("http")) return;
        if (url.equals(currentUrl) && bitmap != null) return;
        if (loading) return;
        loading = true;

        final String u = url;
        final Context app = c.getApplicationContext();
        new Thread(() -> {
            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(u).openConnection();
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(30000);
                conn.setRequestProperty("User-Agent", "Mozilla/5.0");
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                try (InputStream in = conn.getInputStream()) {
                    byte[] buf = new byte[8192];
                    int n;
                    int total = 0;
                    while ((n = in.read(buf)) > 0) {
                        bos.write(buf, 0, n);
                        total += n;
                        if (total > 10000000) throw new IOException("too big");
                    }
                }
                byte[] data = bos.toByteArray();

                BitmapFactory.Options bounds = new BitmapFactory.Options();
                bounds.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(data, 0, data.length, bounds);
                int side = Math.max(bounds.outWidth, bounds.outHeight);
                int sample = 1;
                while (side / sample > 1024) sample *= 2;
                BitmapFactory.Options opts = new BitmapFactory.Options();
                opts.inSampleSize = sample;
                Bitmap bm = BitmapFactory.decodeByteArray(data, 0, data.length, opts);

                if (bm != null) {
                    File f = new File(app.getFilesDir(), "bot_pic_live.png");
                    try (FileOutputStream fo = new FileOutputStream(f)) {
                        bm.compress(Bitmap.CompressFormat.PNG, 100, fo);
                    }
                    app.getSharedPreferences("lh", Context.MODE_PRIVATE)
                            .edit().putString("pic_url", u).apply();
                    currentUrl = u;
                    bitmap = bm;
                    new Handler(Looper.getMainLooper()).post(() -> {
                        if (onChange != null) onChange.run();
                    });
                }
            } catch (Exception ignored) {
            } finally {
                loading = false;
            }
        }).start();
    }
}
