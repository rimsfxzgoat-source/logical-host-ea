package com.logicalhost.app;

import android.content.Context;

import org.json.JSONObject;

/**
 * The subscription as the web app reports it. The app checks it before the bot can run.
 * Before the first sync (no data yet) the app allows the bot, so existing users are not locked out.
 */
final class Subscription {

    static final String PREFS = "lh_sub";

    private Subscription() {}

    static void save(Context c, String json) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("json", json)
                .putLong("savedAt", System.currentTimeMillis())
                .apply();
    }

    static String raw(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("json", "");
    }

    /** true = the bot may run. Lifetime never ends; a 2-month plan ends at expiresAt (ms). */
    static boolean allowed(Context c) {
        String j = raw(c);
        if (j.isEmpty()) return true;
        try {
            JSONObject o = new JSONObject(j);
            if (!"active".equals(o.optString("status", "none"))) return false;
            if ("lifetime".equals(o.optString("plan", ""))) return true;
            long exp = o.optLong("expiresAt", 0);
            return exp == 0 || System.currentTimeMillis() < exp;
        } catch (Exception e) {
            return false;
        }
    }
}
