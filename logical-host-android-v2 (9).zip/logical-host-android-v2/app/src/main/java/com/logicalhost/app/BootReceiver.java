package com.logicalhost.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** After a phone restart, the scheduled alarms are set again. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())) {
            Schedule.arm(c);
        }
    }
}
