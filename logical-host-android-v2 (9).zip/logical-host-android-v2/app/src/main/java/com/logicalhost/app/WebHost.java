package com.logicalhost.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.MutableContextWrapper;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Collections;

/**
 * One single WebView for the whole app. The screen attaches to it when open.
 * When the screen closes it is parked in a tiny overlay, so the page (and the bot
 * running inside it) keeps working.
 */
public final class WebHost {

    static final String HOME_URL = "https://logical-host-ea.base44.app/android";
    private static final String APP_DOMAIN = "base44.app";
    // Off on purpose: moving the page between windows made the console blank.
    private static final boolean PARK_IN_OVERLAY = false;

    interface ChooserHandler {
        boolean show(ValueCallback<Uri[]> cb, WebChromeClient.FileChooserParams p);
    }

    static Activity activity;          // set while the screen is showing the WebView
    static ChooserHandler chooser;     // file picker, set by MainActivity

    private static WebView web;
    private static MutableContextWrapper ctx;
    private static Context appContext;
    private static String bridgeJs = "";
    private static boolean parked = false;
    private static WindowManager parkWm;

    private WebHost() {}

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    static WebView get(Context c) {
        if (web != null) return web;

        appContext = c.getApplicationContext();
        bridgeJs = readAsset(appContext, "bridge.js");
        ctx = new MutableContextWrapper(appContext);

        web = new WebView(ctx);
        web.setBackgroundColor(Color.parseColor("#05070c"));

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);   // login and keys live in localStorage
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);

        web.addJavascriptInterface(new NotifyBridge(appContext), "AndroidNotify");

        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(
                    web, bridgeJs, Collections.singleton("https://*." + APP_DOMAIN));
        }

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                if (!r.isForMainFrame()) return false;
                Uri u = r.getUrl();
                String scheme = u.getScheme();
                if ("blob".equals(scheme) || "data".equals(scheme) || "about".equals(scheme)) {
                    return false;
                }
                String host = u.getHost();
                if (host != null && (host.equals(APP_DOMAIN) || host.endsWith("." + APP_DOMAIN))) {
                    return false;
                }
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW, u);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    appContext.startActivity(i);
                } catch (Exception ignored) {
                }
                return true;
            }

            @Override
            public void onPageStarted(WebView v, String url, Bitmap favicon) {
                v.evaluateJavascript(bridgeJs, null);
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                v.evaluateJavascript(bridgeJs, null);
                v.evaluateJavascript("window.__lhSetHidden&&window.__lhSetHidden("
                        + (!MainActivity.visible) + ")", null);
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) {
                    String html = "<html><body style='background:#05070c;color:#fff;"
                            + "font-family:sans-serif;text-align:center;padding-top:30vh'>"
                            + "<h2>No internet</h2><p>Check your connection.</p>"
                            + "<p><a style='color:#4da3ff' href='" + HOME_URL + "'>Try again</a></p>"
                            + "</body></html>";
                    v.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
                }
            }

            @Override
            public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) {
                Activity a = activity;
                destroy();
                if (a != null) {
                    a.recreate();
                } else {
                    get(appContext);
                    park(appContext);
                }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb,
                                             FileChooserParams p) {
                ChooserHandler h = chooser;
                if (h == null) {
                    cb.onReceiveValue(null);
                    return true;
                }
                return h.show(cb, p);
            }
        });

        web.loadUrl(HOME_URL);
        return web;
    }

    /** Show the WebView inside the screen. */
    static void attach(Activity a, ViewGroup container) {
        WebView w = get(a);
        unpark();
        ViewParent p = w.getParent();
        if (p != container) {
            if (p instanceof ViewGroup) ((ViewGroup) p).removeView(w);
            container.addView(w, new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }
        ctx.setBaseContext(a);
        activity = a;
        w.requestFocus();
        refresh();
    }

    /** Wake the page up and make Android draw it again (fixes a blank screen). */
    static void refresh() {
        final WebView w = web;
        if (w == null) return;
        w.onResume();
        w.resumeTimers();
        w.setVisibility(View.INVISIBLE);
        w.postDelayed(() -> {
            if (web != w) return;
            w.setVisibility(View.VISIBLE);
            w.requestLayout();
            w.invalidate();
            w.evaluateJavascript(
                    "try{window.dispatchEvent(new Event('resize'))}catch(e){}", null);
        }, 80);
        w.postDelayed(() -> {
            if (web != w) return;
            w.requestLayout();
            w.invalidate();
        }, 500);
    }

    static void runJs(String js) {
        if (web != null) web.evaluateJavascript(js, null);
    }

    /** Tell the page if the app screen is hidden (the floating console is used then). */
    static void setHidden(boolean hidden) {
        runJs("window.__lhSetHidden&&window.__lhSetHidden(" + hidden + ")");
    }

    /** Ask the page to send the console contents now. */
    static void requestSnapshot() {
        runJs("window.__lhSnap&&window.__lhSnap()");
    }

    /** Press a button in the page (for example CLEAR). */
    static void clickInPage(String selector) {
        runJs("(function(){var b=document.querySelector('" + selector
                + "');if(b)b.click();})()");
    }

    private static final String START_JS =
            "(function(){try{if(window.lhStartBot){return String(!!window.lhStartBot());}"
            + "return 'false';}catch(e){return 'false';}})();";

    /** Ask the page to start the bot (window.lhStartBot). Reports "true" or "false". */
    static void startBot(Context c, android.webkit.ValueCallback<String> cb) {
        if (web == null) {
            WebHost.get(c);
            cb.onReceiveValue("false");
            return;
        }
        web.evaluateJavascript(START_JS, cb);
    }

    /** Open the bot console sheet in the page (same as tapping the page's own bubble). */
    static void openConsole() {
        final WebView w = web;
        if (w == null) return;
        final String open = "(function(){try{if(!document.querySelector('.lcx-sheet')){"
                + "var b=document.querySelector('.float-bubble');if(b)b.click();}}catch(e){}})();";
        w.postDelayed(() -> {
            if (web == w) w.evaluateJavascript(open, null);
        }, 600);
        w.postDelayed(() -> {
            if (web != w) return;
            w.evaluateJavascript(open, null);
            // if the page is completely empty, load it again
            w.evaluateJavascript(
                    "(function(){return document.body?document.body.innerText.length:-1})()",
                    v -> {
                        if (web == w && ("0".equals(v) || "-1".equals(v)) && w.getProgress() == 100) {
                            w.reload();
                        }
                    });
        }, 2000);
    }

    /** Screen destroyed: take the WebView out of it. The page keeps running. */
    static void detach(Context c) {
        if (web == null) return;
        ViewParent p = web.getParent();
        if (p instanceof ViewGroup) ((ViewGroup) p).removeView(web);
        activity = null;
        ctx.setBaseContext(c.getApplicationContext());
        web.resumeTimers();
        park(c);
    }

    /** Keep the page "visible" in a 1px overlay so Android does not slow it down. */
    static void park(Context c) {
        if (web == null || parked) return;
        web.onResume();
        web.resumeTimers();
        if (!PARK_IN_OVERLAY || !Settings.canDrawOverlays(c)) return;
        try {
            parkWm = (WindowManager) c.getApplicationContext()
                    .getSystemService(Context.WINDOW_SERVICE);
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    1, 1,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                            | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.START;
            parkWm.addView(web, lp);
            parked = true;
        } catch (Exception e) {
            parked = false;
        }
    }

    private static void unpark() {
        if (parked && parkWm != null && web != null) {
            try {
                parkWm.removeView(web);
            } catch (Exception ignored) {
            }
        }
        parked = false;
    }

    static boolean canGoBack() {
        return web != null && web.canGoBack();
    }

    static void goBack() {
        if (web != null) web.goBack();
    }

    /** Start over: clears the saved login, page data, settings and schedule. */
    static void resetAll(Context c) {
        destroy();
        try {
            android.webkit.WebStorage.getInstance().deleteAllData();
        } catch (Exception ignored) {
        }
        CookieManager cm = CookieManager.getInstance();
        cm.removeAllCookies(null);
        cm.flush();
        try {
            WebView tmp = new WebView(c.getApplicationContext());
            tmp.clearCache(true);
            tmp.clearHistory();
            tmp.destroy();
        } catch (Exception ignored) {
        }
        c.stopService(new Intent(c, KeepAliveService.class));
        Schedule.save(c, false, 0, 0, true, 0);
        String[] prefs = {"lh", "lh_sched", "lh_push", "lh_sigreq"};
        for (String p : prefs) {
            c.getSharedPreferences(p, Context.MODE_PRIVATE).edit().clear().commit();
        }
        new java.io.File(c.getFilesDir(), "bot_pic_live.png").delete();
        BotPicture.bitmap = null;
        KeepAliveService.bubbleWanted = false;
    }

    static void destroy() {
        if (web == null) return;
        unpark();
        ViewParent p = web.getParent();
        if (p instanceof ViewGroup) ((ViewGroup) p).removeView(web);
        web.destroy();
        web = null;
        ctx = null;
        activity = null;
        parked = false;
    }

    private static String readAsset(Context c, String name) {
        try (InputStream in = c.getAssets().open(name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }
}
