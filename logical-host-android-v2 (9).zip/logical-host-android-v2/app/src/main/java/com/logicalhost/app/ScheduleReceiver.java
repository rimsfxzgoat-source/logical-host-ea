package com.logicalhost.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Receives the alarms for the early warning and the scheduled start. */
public class ScheduleReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        String a = i.getAction();
        if (Schedule.ACTION_PRE.equals(a)) {
            Schedule.onPre(c);
        } else if (Schedule.ACTION_START.equals(a)) {
            Schedule.onStart(c);
        }
    }
}
