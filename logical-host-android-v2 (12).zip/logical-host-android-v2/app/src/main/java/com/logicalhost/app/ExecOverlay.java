package com.logicalhost.app;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.WindowManager;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * The execution screen over other apps. It shows only while a trade executes, when the
 * app is in the background. It disappears on X, or about 2.5 s after the trade finishes.
 */
final class ExecOverlay {

    private static final int BLUE = 0xFF6F8BFF;
    private static final int GREEN = 0xFF33D17A;
    private static final int ORANGE = 0xFFFF8A3D;
    private static final int INK = 0xFFF3F5FB;
    private static final int INK_DIM = 0xFF8891A7;
    private static final int INK_FAINT = 0xFF5A6178;

    private final Context ctx;
    private final WindowManager wm;
    private final float d;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable hideLater = this::hide;

    private FrameLayout root;
    private WindowManager.LayoutParams lp;
    private FrameLayout orbit;
    private ImageView avatar;
    private TextView head, sub, badge;
    private LinearLayout lines;
    private ObjectAnimator spin;
    private boolean shown = false;
    private boolean dismissed = false;
    private boolean prevExec = false;

    ExecOverlay(Context c) {
        ctx = c;
        wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
        d = c.getResources().getDisplayMetrics().density;
    }

    private int dp(float v) {
        return (int) (v * d + 0.5f);
    }

    private int alpha(int color, float a) {
        return (color & 0x00FFFFFF) | (((int) (a * 255f)) << 24);
    }

    private GradientDrawable box(int fill, float radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private TextView tv(String text, float sp, int color, boolean bold) {
        TextView t = new TextView(ctx);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    /** Called with the JSON from the web page (see bridge.js). */
    void update(String json) {
        try {
            JSONObject o = new JSONObject(json);
            boolean on = o.optBoolean("on", false);
            boolean exec = on && o.optBoolean("executing", false);

            // Off, or the app is on screen (its own execution screen is used then).
            if (!on || MainActivity.visible) {
                prevExec = false;
                dismissed = false;
                h.removeCallbacks(hideLater);
                hide();
                return;
            }

            if (exec) {
                if (!prevExec) dismissed = false;     // a new trade starts
                h.removeCallbacks(hideLater);
                if (!dismissed && Settings.canDrawOverlays(ctx)) {
                    show();
                    render(o, true);
                }
            } else if (shown) {
                render(o, false);                      // trade just finished: keep the result briefly
                if (prevExec) h.postDelayed(hideLater, 2500);
            }
            prevExec = exec;
        } catch (Exception ignored) {
        }
    }

    private void show() {
        if (shown) return;
        build();
        try {
            wm.addView(root, lp);
            shown = true;
            spin.start();
        } catch (Exception e) {
            shown = false;
            root = null;
        }
    }

    private void hide() {
        if (spin != null) spin.cancel();
        if (shown) {
            try {
                wm.removeView(root);
            } catch (Exception ignored) {
            }
        }
        shown = false;
        root = null;
    }

    private void dismiss() {
        dismissed = true;
        h.removeCallbacks(hideLater);
        hide();
    }

    private void build() {
        int sw = ctx.getResources().getDisplayMetrics().widthPixels;
        int w = Math.min((int) (sw * 0.92f), dp(360));

        root = new FrameLayout(ctx);
        LinearLayout card = new LinearLayout(ctx);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackground(box(0xF2080B14, 22, alpha(BLUE, 0.35f)));
        card.setClipToOutline(true);
        card.setOutlineProvider(ViewOutlineProvider.BACKGROUND);

        // top row: brand, sub line, X
        LinearLayout top = new LinearLayout(ctx);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout brand = new LinearLayout(ctx);
        brand.setOrientation(LinearLayout.VERTICAL);
        TextView name = tv("LOGICAL HOST", 13, INK, true);
        name.setLetterSpacing(0.2f);
        sub = tv("", 9.5f, INK_DIM, true);
        sub.setLetterSpacing(0.12f);
        brand.addView(name);
        brand.addView(sub);
        top.addView(brand, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView x = tv("\u2715", 13, INK_DIM, true);
        x.setGravity(Gravity.CENTER);
        x.setBackground(box(0x0DFFFFFF, 10, 0));
        x.setOnClickListener(v -> dismiss());
        top.addView(x, new LinearLayout.LayoutParams(dp(30), dp(30)));
        card.addView(top, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        // vortex: dots orbit the bot picture
        FrameLayout vortexBox = new FrameLayout(ctx);
        int box = dp(150);
        orbit = new FrameLayout(ctx);
        for (int i = 0; i < 8; i++) {
            double a = Math.toRadians(i * 45);
            int cx = box / 2 + (int) (dp(62) * Math.cos(a));
            int cy = box / 2 + (int) (dp(62) * Math.sin(a));
            View dot = new View(ctx);
            dot.setBackground(box(BLUE, 4, 0));
            FrameLayout.LayoutParams dp8 = new FrameLayout.LayoutParams(dp(8), dp(8));
            dp8.leftMargin = cx - dp(4);
            dp8.topMargin = cy - dp(4);
            orbit.addView(dot, dp8);
        }
        vortexBox.addView(orbit, new FrameLayout.LayoutParams(box, box, Gravity.CENTER));
        avatar = new ImageView(ctx);
        avatar.setBackgroundResource(R.drawable.bubble_bg);
        avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
        avatar.setPadding(dp(2), dp(2), dp(2), dp(2));
        avatar.setClipToOutline(true);
        avatar.setOutlineProvider(ViewOutlineProvider.BACKGROUND);
        if (BotPicture.bitmap != null) {
            avatar.setImageBitmap(BotPicture.bitmap);
        } else {
            avatar.setImageResource(R.drawable.bot_picture);
        }
        vortexBox.addView(avatar, new FrameLayout.LayoutParams(dp(60), dp(60), Gravity.CENTER));
        card.addView(vortexBox, new LinearLayout.LayoutParams(box, box));
        ((LinearLayout.LayoutParams) vortexBox.getLayoutParams()).gravity = Gravity.CENTER_HORIZONTAL;

        // status feed
        LinearLayout feed = new LinearLayout(ctx);
        feed.setOrientation(LinearLayout.VERTICAL);
        feed.setPadding(dp(12), dp(10), dp(12), dp(10));
        feed.setBackground(box(0x990A0E1A, 14, alpha(BLUE, 0.2f)));
        badge = tv("", 9.5f, BLUE, true);
        badge.setLetterSpacing(0.2f);
        feed.addView(badge);
        lines = new LinearLayout(ctx);
        lines.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        lp1.topMargin = dp(6);
        feed.addView(lines, lp1);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        fp.topMargin = dp(12);
        card.addView(feed, fp);

        // footer
        TextView foot = tv("LOGICAL HOST \u00B7 AUTO EXECUTION", 10, 0xFFFFFFFF, true);
        foot.setGravity(Gravity.CENTER);
        foot.setLetterSpacing(0.14f);
        foot.setPadding(dp(10), dp(10), dp(10), dp(10));
        foot.setBackground(box(0xFF4D6FFF, 14, 0));
        LinearLayout.LayoutParams ffp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        ffp.topMargin = dp(12);
        card.addView(foot, ffp);

        root.addView(card, new FrameLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT));

        spin = ObjectAnimator.ofFloat(orbit, View.ROTATION, 0f, 360f);
        spin.setInterpolator(new LinearInterpolator());
        spin.setDuration(3000);
        spin.setRepeatCount(ObjectAnimator.INFINITE);

        lp = new WindowManager.LayoutParams(
                w, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = (sw - w) / 2;
        lp.y = dp(70);
    }

    private void render(JSONObject o, boolean executing) {
        if (root == null) return;
        try {
            int col = executing ? GREEN : BLUE;
            badge.setText(executing ? "EXECUTING TRADE" : "AWAITING SIGNAL");
            badge.setTextColor(col);
            String s = o.optString("sub", "");
            sub.setText(s.toUpperCase());

            if (spin != null) spin.setDuration(executing ? 1200 : 3000);

            lines.removeAllViews();
            JSONArray arr = o.optJSONArray("lines");
            int n = arr == null ? 0 : Math.min(arr.length(), 5);
            if (n == 0) {
                TextView w = tv(">> WAITING FOR SIGNAL...", 11, GREEN, false);
                w.setTypeface(Typeface.MONOSPACE);
                lines.addView(w);
            }
            for (int i = 0; i < n; i++) {
                String text = arr.optString(i, "");
                boolean bad = text.toLowerCase().contains("error") || text.toLowerCase().contains("fail");
                TextView t = tv(">> " + text, 11, bad ? ORANGE : (i == 0 ? GREEN : alpha(GREEN, 0.5f)), i == 0);
                t.setTypeface(Typeface.MONOSPACE);
                t.setSingleLine(true);
                t.setPadding(0, dp(2), 0, dp(2));
                lines.addView(t);
            }
        } catch (Exception ignored) {
        }
    }
}
