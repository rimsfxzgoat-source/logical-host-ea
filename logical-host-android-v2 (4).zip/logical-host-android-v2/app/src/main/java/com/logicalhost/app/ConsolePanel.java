package com.logicalhost.app;

import android.content.Context;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

/** The Bot Console as a floating panel that draws over other apps. */
public class ConsolePanel {

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private static final int BG = 0xFF0B1022;
    private static final int CARD = 0xFF111A3D;
    private static final int ITEM = 0xFF0F1630;
    private static final int LINE = 0xFF2B3A8A;
    private static final int TEXT = 0xFFFFFFFF;
    private static final int MUTED = 0xFF9AA4C8;
    private static final int GREEN = 0xFF22C88A;
    private static final int RED = 0xFFFF5A5F;
    private static final int AMBER = 0xFFFFB454;
    private static final int BLUE = 0xFF4DA3FF;
    private static final int SKY = 0xFF8FB6FF;
    private static final int GRAY = 0xFF6B7494;

    private final Context ctx;
    private final WindowManager wm;
    private final float d;

    private ImageView logo;
    private LinearLayout root;
    private WindowManager.LayoutParams wlp;
    private TextView nameTv, stateTv, linkTitleTv, linkSubTv, badgeTv, countTv;
    private LinearLayout list;
    private ScrollView scroll;
    private boolean shown = false;
    private String lastJson = "";
    private int posX = Integer.MIN_VALUE;
    private int posY = Integer.MIN_VALUE;

    ConsolePanel(Context c) {
        ctx = c;
        wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
        d = c.getResources().getDisplayMetrics().density;
    }

    boolean isShown() {
        return shown;
    }

    void show() {
        if (shown || !Settings.canDrawOverlays(ctx)) return;
        build();
        try {
            wm.addView(root, wlp);
            shown = true;
        } catch (Exception e) {
            shown = false;
            root = null;
            return;
        }
        if (!lastJson.isEmpty()) render(lastJson);
        WebHost.requestSnapshot();
    }

    void hide() {
        if (!shown) return;
        try {
            wm.removeView(root);
        } catch (Exception ignored) {
        }
        shown = false;
        root = null;
    }

    private void paintPicture() {
        if (logo == null) return;
        if (BotPicture.bitmap != null) {
            logo.setImageBitmap(BotPicture.bitmap);
        } else {
            logo.setImageResource(R.drawable.bot_picture);
        }
    }

    void refreshPicture() {
        if (shown) paintPicture();
    }

    void update(String json) {
        lastJson = json;
        if (shown) render(json);
    }

    // ---------------------------------------------------------------- build

    private int dp(float v) {
        return (int) (v * d + 0.5f);
    }

    private int alpha(int color, float a) {
        return (color & 0x00FFFFFF) | (((int) (a * 255f)) << 24);
    }

    private GradientDrawable box(int fill, float radiusDp, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private TextView tv(String text, float sp, int color, boolean bold) {
        TextView t = new TextView(ctx);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView btn(String label) {
        TextView t = tv(label, 11, BLUE, true);
        t.setLetterSpacing(0.1f);
        t.setPadding(dp(11), dp(7), dp(11), dp(7));
        t.setBackground(box(0, 20, alpha(BLUE, 0.5f)));
        return t;
    }

    private LinearLayout.LayoutParams ll(int w, int h, float weight, int topDp, int leftDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h, weight);
        p.topMargin = dp(topDp);
        p.leftMargin = dp(leftDp);
        return p;
    }

    private void build() {
        int sw = ctx.getResources().getDisplayMetrics().widthPixels;
        int sh = ctx.getResources().getDisplayMetrics().heightPixels;
        int w = Math.min((int) (sw * 0.94f), dp(440));
        int h = (int) (sh * 0.70f);

        root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(box(BG, 24, LINE));
        root.setPadding(dp(12), dp(2), dp(12), dp(12));

        // header: grip in the middle, close button on the right (drag here)
        FrameLayout head = new FrameLayout(ctx);
        View grip = new View(ctx);
        grip.setBackground(box(0xFF3A4676, 3, 0));
        head.addView(grip, new FrameLayout.LayoutParams(dp(44), dp(5), Gravity.CENTER));
        TextView close = tv("\u2715", 18, MUTED, true);
        close.setPadding(dp(14), dp(8), dp(6), dp(8));
        head.addView(close, new FrameLayout.LayoutParams(
                WRAP, WRAP, Gravity.END | Gravity.CENTER_VERTICAL));
        close.setOnClickListener(v -> {
            KeepAliveService s = KeepAliveService.instance;
            if (s != null) s.hidePanel();
        });
        root.addView(head, ll(MATCH, dp(42), 0, 0, 0));
        drag(head);

        // hero card
        LinearLayout hero = new LinearLayout(ctx);
        hero.setOrientation(LinearLayout.HORIZONTAL);
        hero.setGravity(Gravity.CENTER_VERTICAL);
        hero.setPadding(dp(12), dp(12), dp(12), dp(12));
        hero.setBackground(box(CARD, 18, LINE));
        logo = new ImageView(ctx);
        logo.setBackgroundResource(R.drawable.bubble_bg);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        logo.setPadding(dp(2), dp(2), dp(2), dp(2));
        logo.setClipToOutline(true);
        logo.setOutlineProvider(ViewOutlineProvider.BACKGROUND);
        paintPicture();
        hero.addView(logo, new LinearLayout.LayoutParams(dp(54), dp(54)));
        LinearLayout col = new LinearLayout(ctx);
        col.setOrientation(LinearLayout.VERTICAL);
        TextView kicker = tv("BOT CONSOLE", 11, 0xFF7B8CFF, true);
        kicker.setLetterSpacing(0.2f);
        nameTv = tv("BOT", 20, TEXT, true);
        nameTv.setSingleLine(true);
        nameTv.setEllipsize(TextUtils.TruncateAt.END);
        stateTv = tv("", 11, SKY, true);
        stateTv.setLetterSpacing(0.08f);
        stateTv.setPadding(dp(10), dp(5), dp(10), dp(5));
        col.addView(kicker);
        col.addView(nameTv);
        col.addView(stateTv, ll(WRAP, WRAP, 0, 6, 0));
        hero.addView(col, ll(0, WRAP, 1f, 0, 12));
        root.addView(hero, ll(MATCH, WRAP, 0, 0, 0));

        // self-host PC card
        LinearLayout link = new LinearLayout(ctx);
        link.setOrientation(LinearLayout.HORIZONTAL);
        link.setGravity(Gravity.CENTER_VERTICAL);
        link.setPadding(dp(14), dp(12), dp(14), dp(12));
        link.setBackground(box(CARD, 16, LINE));
        LinearLayout lcol = new LinearLayout(ctx);
        lcol.setOrientation(LinearLayout.VERTICAL);
        linkTitleTv = tv("SELF-HOST PC", 12, TEXT, true);
        linkTitleTv.setLetterSpacing(0.15f);
        linkSubTv = tv("", 12.5f, MUTED, false);
        lcol.addView(linkTitleTv);
        lcol.addView(linkSubTv);
        badgeTv = tv("", 12, RED, true);
        badgeTv.setLetterSpacing(0.1f);
        badgeTv.setPadding(dp(12), dp(6), dp(12), dp(6));
        link.addView(lcol, ll(0, WRAP, 1f, 0, 0));
        link.addView(badgeTv, ll(WRAP, WRAP, 0, 0, 8));
        root.addView(link, ll(MATCH, WRAP, 0, 10, 0));

        // live activity header
        LinearLayout act = new LinearLayout(ctx);
        act.setOrientation(LinearLayout.HORIZONTAL);
        act.setGravity(Gravity.CENTER_VERTICAL);
        TextView actT = tv("LIVE ACTIVITY", 12, TEXT, true);
        actT.setLetterSpacing(0.15f);
        countTv = tv("0", 11, BLUE, true);
        countTv.setPadding(dp(9), dp(3), dp(9), dp(3));
        countTv.setBackground(box(alpha(BLUE, 0.15f), 20, 0));
        TextView clear = btn("CLEAR");
        clear.setOnClickListener(v -> WebHost.clickInPage(".lhf-actions button"));
        TextView open = btn("OPEN APP");
        open.setOnClickListener(v -> {
            KeepAliveService s = KeepAliveService.instance;
            if (s != null) s.openApp();
        });
        act.addView(actT);
        act.addView(countTv, ll(WRAP, WRAP, 0, 0, 8));
        act.addView(new View(ctx), ll(0, 1, 1f, 0, 0));
        act.addView(clear, ll(WRAP, WRAP, 0, 0, 0));
        act.addView(open, ll(WRAP, WRAP, 0, 0, 6));
        root.addView(act, ll(MATCH, WRAP, 0, 12, 4));

        // activity list
        scroll = new ScrollView(ctx);
        list = new LinearLayout(ctx);
        list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list, new ViewGroup.LayoutParams(MATCH, WRAP));
        root.addView(scroll, ll(MATCH, 0, 1f, 8, 0));

        wlp = new WindowManager.LayoutParams(
                w, h,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        wlp.gravity = Gravity.TOP | Gravity.START;
        wlp.x = posX == Integer.MIN_VALUE ? (sw - w) / 2 : posX;
        wlp.y = posY == Integer.MIN_VALUE ? (int) (sh * 0.14f) : posY;
    }

    private void drag(View handle) {
        handle.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy;
            float tx, ty;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = wlp.x;
                        sy = wlp.y;
                        tx = e.getRawX();
                        ty = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        wlp.x = sx + (int) (e.getRawX() - tx);
                        wlp.y = sy + (int) (e.getRawY() - ty);
                        posX = wlp.x;
                        posY = wlp.y;
                        try {
                            wm.updateViewLayout(root, wlp);
                        } catch (Exception ignored) {
                        }
                        return true;
                    default:
                        return true;
                }
            }
        });
    }

    // --------------------------------------------------------------- render

    private void render(String json) {
        if (root == null) return;
        try {
            JSONObject o = new JSONObject(json);

            nameTv.setText(o.optString("name", "BOT"));

            String cls = o.optString("stateCls", "ana");
            int sc = "exec".equals(cls) ? AMBER : "mon".equals(cls) ? GREEN : SKY;
            String st = o.optString("state", "");
            stateTv.setText(st.isEmpty() ? "WAITING FOR MENTOR SIGNAL" : st);
            stateTv.setTextColor(sc);
            stateTv.setBackground(box(alpha(sc, 0.15f), 10, alpha(sc, 0.5f)));

            linkTitleTv.setText(o.optString("linkTitle", "SELF-HOST PC"));
            linkSubTv.setText(o.optString("linkSub", ""));
            String lc = o.optString("linkCls", "off");
            int bc = "on".equals(lc) ? GREEN : "off".equals(lc) ? RED : AMBER;
            String badge = o.optString("badge", "");
            badgeTv.setText(badge.isEmpty() ? lc.toUpperCase() : badge);
            badgeTv.setTextColor(bc);
            badgeTv.setBackground(box(alpha(bc, 0.15f), 12, alpha(bc, 0.5f)));

            JSONArray items = o.optJSONArray("items");
            int n = items == null ? 0 : items.length();
            countTv.setText(String.valueOf(n));
            list.removeAllViews();
            if (n == 0) {
                list.addView(card("idle", "Waiting for signal",
                        "Bot activity will show here", "", ""), ll(MATCH, WRAP, 0, 8, 0));
            } else {
                for (int i = 0; i < n; i++) {
                    JSONObject it = items.getJSONObject(i);
                    list.addView(card(it.optString("tone", "idle"), it.optString("title"),
                            it.optString("detail"), it.optString("ts"), it.optString("sym")),
                            ll(MATCH, WRAP, 0, 8, 0));
                }
            }
            scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
        } catch (Exception ignored) {
        }
    }

    private View card(String tone, String title, String detail, String ts, String sym) {
        int tc = "ok".equals(tone) ? GREEN
                : "err".equals(tone) ? RED
                : "warn".equals(tone) ? AMBER
                : "idle".equals(tone) ? GRAY : BLUE;

        LinearLayout c = new LinearLayout(ctx);
        c.setOrientation(LinearLayout.HORIZONTAL);
        c.setBackground(box(ITEM, 14, 0xFF1A2350));

        View bar = new View(ctx);
        bar.setBackground(box(tc, 2, 0));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(4), MATCH);
        bp.setMargins(dp(8), dp(8), 0, dp(8));
        c.addView(bar, bp);

        LinearLayout text = new LinearLayout(ctx);
        text.setOrientation(LinearLayout.VERTICAL);
        text.setPadding(dp(12), dp(10), dp(8), dp(10));
        text.addView(tv(title, 15, TEXT, true));
        if (!detail.isEmpty()) text.addView(tv(detail, 12.5f, MUTED, false));
        c.addView(text, ll(0, WRAP, 1f, 0, 0));

        LinearLayout right = new LinearLayout(ctx);
        right.setOrientation(LinearLayout.VERTICAL);
        right.setGravity(Gravity.END);
        right.setPadding(0, dp(10), dp(12), dp(10));
        if (!ts.isEmpty()) {
            TextView t = tv(ts, 12, 0xFF7F89B0, false);
            t.setTypeface(Typeface.MONOSPACE);
            right.addView(t);
        }
        if (!sym.isEmpty()) right.addView(tv(sym, 11, BLUE, true));
        c.addView(right, new LinearLayout.LayoutParams(WRAP, WRAP));
        return c;
    }
}
