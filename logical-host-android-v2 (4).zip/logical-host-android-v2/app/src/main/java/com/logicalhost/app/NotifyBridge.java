package com.logicalhost.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.webkit.JavascriptInterface;

import org.json.JSONObject;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

public class NotifyBridge {

    static final String CHANNEL_ID = "signals";
    // true = also show a notification while the app is on screen
    private static final boolean NOTIFY_WHEN_VISIBLE = false;

    private final Context ctx;
    private static boolean askedOverlay = false;
    private int nextId = 1000;
    private String lastKey = "";
    private long lastAt = 0;

    public NotifyBridge(Context c) {
        ctx = c.getApplicationContext();
        NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID, "Signals", NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("Trade signals and scanner alerts");
        ch.enableVibration(true);
        ch.setVibrationPattern(new long[]{0, 200, 100, 200});
        ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        ctx.getSystemService(NotificationManager.class).createNotificationChannel(ch);
    }

    @JavascriptInterface
    public boolean isNative() {
        return true;
    }

    @JavascriptInterface
    public void show(String title, String body) {
        if (title == null) title = "Logical Host";
        if (body == null) body = "";
        if (MainActivity.visible && !NOTIFY_WHEN_VISIBLE) return;

        synchronized (this) {
            String key = title + "|" + body;
            long now = System.currentTimeMillis();
            if (key.equals(lastKey) && now - lastAt < 3000) return; // same alert twice
            lastKey = key;
            lastAt = now;
        }

        try {
            Intent i = new Intent(ctx, MainActivity.class);
            i.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi = PendingIntent.getActivity(
                    ctx, 0, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

            NotificationCompat.Builder b = new NotificationCompat.Builder(ctx, CHANNEL_ID)
                    .setSmallIcon(R.drawable.ic_notif)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                    .setDefaults(NotificationCompat.DEFAULT_ALL)
                    .setAutoCancel(true)
                    .setContentIntent(pi);

            NotificationManagerCompat nm = NotificationManagerCompat.from(ctx);
            if (nm.areNotificationsEnabled()) {
                nm.notify(nextId++, b.build());
            }
        } catch (SecurityException ignored) {
        }
    }


    // Called by bridge.js when the bot turns ON or OFF.
    @JavascriptInterface
    public void botState(boolean on) {
        new Handler(Looper.getMainLooper()).post(() -> {
            KeepAliveService.bubbleWanted = on;
            KeepAliveService s = KeepAliveService.instance;
            if (on) {
                if (!Settings.canDrawOverlays(ctx) && !askedOverlay) {
                    askedOverlay = true;
                    Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + ctx.getPackageName()));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    try {
                        ctx.startActivity(i);
                    } catch (Exception ignored) {
                    }
                }
                if (s != null) s.showBubble();
            } else if (s != null) {
                s.onBotOff();
            }
        });
    }

    // Called by bridge.js with what the page's Bot Console shows (JSON).
    @JavascriptInterface
    public void consoleData(String json) {
        new Handler(Looper.getMainLooper()).post(() -> {
            try {
                String pic = new JSONObject(json).optString("picture", "");
                if (!pic.isEmpty()) BotPicture.use(ctx, pic);
            } catch (Exception ignored) {
            }
            KeepAliveService s = KeepAliveService.instance;
            if (s != null && s.panel != null) s.panel.update(json);
        });
    }

    @JavascriptInterface
    public void showBubble() {
        new Handler(Looper.getMainLooper()).post(() -> {
            KeepAliveService.bubbleWanted = true;
            if (KeepAliveService.instance != null) KeepAliveService.instance.showBubble();
        });
    }

    @JavascriptInterface
    public void hideBubble() {
        new Handler(Looper.getMainLooper()).post(() -> {
            KeepAliveService.bubbleWanted = false;
            if (KeepAliveService.instance != null) KeepAliveService.instance.hideBubble();
        });
    }
}
